from __future__ import annotations

import numpy as np

from cc_nsiea.evidence_audit.controller import AuditControllerConfig, EvidenceAuditController, calibrate_tau_threshold
from cc_nsiea.evidence_audit.kpc import kpc_completeness
from cc_nsiea.evidence_audit.metrics import evaluate_risk_estimators
from cc_nsiea.evidence_audit.retrieval import build_evidence_memory
from cc_nsiea.evidence_audit.rules import fit_motion_energy_rule
from cc_nsiea.protocol import build_four_way_subject_audit_protocol, validate_four_way_audit_protocol


def _synthetic():
    rng = np.random.default_rng(4)
    labels = ["walking", "walking_upstairs", "walking_downstairs", "sitting", "standing", "laying"]
    # Each subject covers all labels to permit valid group splits.
    subjects = np.repeat(np.arange(1, 16), 6)
    y = np.tile(np.asarray(labels, dtype=object), 15)
    X = rng.normal(size=(len(y), 9, 128)).astype(np.float32)
    # Make dynamic samples more energetic for the motion coherence rule.
    dyn = np.isin(y, labels[:3])
    X[dyn, 3:6] *= 2.0
    emb = rng.normal(size=(len(y), 8)).astype(np.float32)
    y_idx = np.asarray([labels.index(v) for v in y], dtype=np.int64)
    return labels, subjects, y, X, emb, y_idx


def test_four_way_subject_protocol_disjoint():
    labels, subjects, y, *_ = _synthetic()
    protocol = build_four_way_subject_audit_protocol(
        y, subjects, labels,
        outer_folds=5,
        model_selection_subjects=2,
        audit_calibration_subjects=2,
        seed=9,
        trials=300,
    )
    validate_four_way_audit_protocol(protocol)
    assert sum(len(f["outer_test_indices"]) for f in protocol["folds"]) == len(y)


def test_read_only_controller_and_metrics():
    labels, subjects, y, X, emb, y_idx = _synthetic()
    memory = build_evidence_memory(emb[:60], y_idx[:60], np.arange(60), subjects[:60], len(labels))
    motion = fit_motion_energy_rule(X[:60], y[:60])
    controller = EvidenceAuditController(
        memory=memory,
        motion_rule=motion,
        labels=labels,
        cfg=AuditControllerConfig(
            round0_top_k_global=3,
            round1_top_k_global=5,
            top_k_class_conditioned=3,
            max_iterations=2,
            evidence_gain_epsilon=0.01,
            tau_stop=0.7,
            aggregation_weights={"confidence": 0.25, "retrieval_support": 0.25, "class_separation": 0.25, "rule_consistency": 0.25},
        ),
    )
    probs = np.full((5, len(labels)), 0.02, dtype=np.float64)
    for i in range(5):
        probs[i, y_idx[60 + i]] = 0.90
    records = controller.audit_batch(
        sample_ids=np.arange(60, 65),
        subject_ids=subjects[60:65],
        X=X[60:65],
        embeddings=emb[60:65],
        probabilities=probs,
        ground_truth=y[60:65],
        fold=0,
    )
    assert all(r["override_permitted"] is False for r in records)
    assert all(r["label_source"] == "neural_temporal_resnet" for r in records)
    assert kpc_completeness(records)["completeness_rate"] == 1.0
    result = evaluate_risk_estimators(
        y_true=y[60:65],
        pred=np.asarray([r["predicted_label"] for r in records], dtype=object),
        confidence=np.asarray([r["confidence"] for r in records]),
        entropy=np.asarray([r["entropy"] for r in records]),
        retrieval_risk=np.asarray([1 - r["retrieval_rounds"][-1]["retrieval_support"] for r in records]),
        rule_risk=np.asarray([1 - r["retrieval_rounds"][-1]["rule_consistency"] for r in records]),
        audit_risk=np.asarray([r["audit_risk"] for r in records]),
    )
    assert result["n"] == 5


def test_tau_calibration_uses_calibration_inputs_only():
    labels, subjects, y, X, emb, y_idx = _synthetic()
    memory = build_evidence_memory(emb[:60], y_idx[:60], np.arange(60), subjects[:60], len(labels))
    motion = fit_motion_energy_rule(X[:60], y[:60])
    probs = np.full((4, len(labels)), 0.03, dtype=np.float64)
    probs[:, 3] = 0.85
    inputs = {
        "sample_ids": np.arange(60, 64),
        "subject_ids": subjects[60:64],
        "X": X[60:64],
        "embeddings": emb[60:64],
        "probabilities": probs,
        "ground_truth": y[60:64],
        "fold": 0,
    }
    def factory(tau):
        return EvidenceAuditController(memory, motion, labels, AuditControllerConfig(
            round0_top_k_global=3, round1_top_k_global=5, top_k_class_conditioned=3,
            max_iterations=2, evidence_gain_epsilon=0.01, tau_stop=tau,
            aggregation_weights={"confidence": .25, "retrieval_support": .25, "class_separation": .25, "rule_consistency": .25},
        ))
    tau, meta = calibrate_tau_threshold(controller_factory=factory, calibration_inputs=inputs, tau_grid=[0.55, 0.7])
    assert tau in {0.55, 0.7}
    assert len(meta["grid"]) == 2


from cc_nsiea.evidence_audit.guided_controller import GuidedAuditControllerConfig, GuidedEvidenceAuditController
from cc_nsiea.evidence_audit.planner import FixedClassContrastPlanner

def test_cc_nsiea_fixed_class_contrast_preserves_neural_label():
    labels, subjects, y, X, emb, y_idx = _synthetic()
    memory = build_evidence_memory(emb[:60], y_idx[:60], np.arange(60), subjects[:60], len(labels))
    motion = fit_motion_energy_rule(X[:60], y[:60])
    controller = GuidedEvidenceAuditController(
        memory=memory,
        motion_rule=motion,
        labels=labels,
        cfg=GuidedAuditControllerConfig(
            round0_top_k_global=3, round1_top_k_global=5, top_k_class_conditioned=3,
            max_iterations=2, evidence_gain_epsilon=0.01, tau_stop=0.99,
            aggregation_weights={"confidence": .25, "retrieval_support": .25, "class_separation": .25, "rule_consistency": .25},
        ),
        planner=FixedClassContrastPlanner(),
        controller_name="CC-NSIEA",
    )
    probs = np.full((1, len(labels)), 0.03, dtype=np.float64)
    probs[0, y_idx[62]] = 0.85
    record = controller.audit_one(
        sample_id=62, subject_id=int(subjects[62]), x=X[62], embedding=emb[62],
        probabilities=probs[0], ground_truth=str(y[62]), fold=0,
    )
    assert record["predicted_label"] == labels[int(np.argmax(probs[0]))]
    assert record["override_permitted"] is False
    if record["planner_decision"] is not None:
        assert record["planner_decision"]["action"] == "CLASS_CONTRAST"
