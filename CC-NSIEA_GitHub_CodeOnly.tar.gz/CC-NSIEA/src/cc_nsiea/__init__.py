"""R9 cross-subject wearable HAR package."""
