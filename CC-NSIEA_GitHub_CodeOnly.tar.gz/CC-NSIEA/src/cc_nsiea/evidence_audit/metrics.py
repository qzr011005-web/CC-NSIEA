from __future__ import annotations

from typing import Any

import numpy as np
from sklearn.metrics import average_precision_score, roc_auc_score


def _safe_roc_auc(y: np.ndarray, score: np.ndarray) -> float | None:
    return None if len(np.unique(y)) < 2 else float(roc_auc_score(y, score))


def _safe_ap(y: np.ndarray, score: np.ndarray) -> float | None:
    return None if len(np.unique(y)) < 2 else float(average_precision_score(y, score))


def _trapezoid_integral(y: np.ndarray, x: np.ndarray) -> float:
    """Integrate with NumPy 1.x and 2.x compatibility.

    ``np.trapezoid`` is unavailable in older NumPy releases such as 1.23/1.24,
    whereas ``np.trapz`` remains available there. The project permits NumPy
    >=1.23, so the compatibility branch is required instead of forcing an
    environment upgrade that could disturb the installed PyTorch stack.
    """
    integrate = getattr(np, "trapezoid", None)
    if integrate is None:
        integrate = np.trapz
    return float(integrate(y, x))


def aurc(error: np.ndarray, risk: np.ndarray) -> float:
    """Area under the selective-risk curve; lower is better."""
    error = np.asarray(error, dtype=np.float64)
    risk = np.asarray(risk, dtype=np.float64)
    if error.size == 0:
        raise ValueError("AURC requires at least one sample.")
    if error.shape != risk.shape:
        raise ValueError("error and risk must have identical shapes.")
    order = np.argsort(risk, kind="stable")  # retain lowest-risk predictions first
    ordered_error = error[order]
    selective_risk = np.cumsum(ordered_error) / np.arange(1, len(ordered_error) + 1)
    coverage = np.arange(1, len(ordered_error) + 1) / len(ordered_error)
    return _trapezoid_integral(selective_risk, coverage)


def risk_coverage_points(error: np.ndarray, risk: np.ndarray, coverages: tuple[float, ...] = (0.5, 0.7, 0.8, 0.9, 1.0)) -> list[dict[str, float]]:
    error = np.asarray(error, dtype=np.float64)
    risk = np.asarray(risk, dtype=np.float64)
    order = np.argsort(risk, kind="stable")
    rows = []
    for cov in coverages:
        n = max(1, int(np.floor(len(order) * float(cov))))
        rows.append({"coverage": float(cov), "selective_risk": float(np.mean(error[order[:n]])), "retained_samples": int(n)})
    return rows


def top_risk_error_rate(error: np.ndarray, risk: np.ndarray, fraction: float) -> float:
    error = np.asarray(error, dtype=np.float64)
    risk = np.asarray(risk, dtype=np.float64)
    n = max(1, int(np.ceil(len(risk) * float(fraction))))
    idx = np.argsort(-risk, kind="stable")[:n]
    return float(np.mean(error[idx]))


def evaluate_risk_estimators(
    *,
    y_true: np.ndarray,
    pred: np.ndarray,
    confidence: np.ndarray,
    entropy: np.ndarray,
    retrieval_risk: np.ndarray,
    rule_risk: np.ndarray,
    audit_risk: np.ndarray,
) -> dict[str, Any]:
    y_true = np.asarray(y_true, dtype=object)
    pred = np.asarray(pred, dtype=object)
    error = (pred != y_true).astype(np.int64)
    risks = {
        "confidence_only": 1.0 - np.asarray(confidence, dtype=np.float64),
        "entropy_only": np.asarray(entropy, dtype=np.float64) / np.log(6.0),
        "retrieval_only": np.asarray(retrieval_risk, dtype=np.float64),
        "rule_only": np.asarray(rule_risk, dtype=np.float64),
        "proposed_audit_risk": np.asarray(audit_risk, dtype=np.float64),
    }
    out: dict[str, Any] = {
        "n": int(len(error)),
        "error_rate": float(np.mean(error)),
        "positive_definition": "neural prediction is incorrect",
        "estimators": {},
    }
    for name, risk in risks.items():
        out["estimators"][name] = {
            "error_auroc": _safe_roc_auc(error, risk),
            "error_auprc": _safe_ap(error, risk),
            "aurc": aurc(error, risk),
            "top_10pct_risk_error_rate": top_risk_error_rate(error, risk, 0.10),
            "top_20pct_risk_error_rate": top_risk_error_rate(error, risk, 0.20),
            "risk_coverage": risk_coverage_points(error, risk),
        }
    base = out["estimators"]["confidence_only"]
    proposed = out["estimators"]["proposed_audit_risk"]
    out["paired_delta_vs_confidence"] = {
        "error_auroc": None if base["error_auroc"] is None or proposed["error_auroc"] is None else float(proposed["error_auroc"] - base["error_auroc"]),
        "error_auprc": None if base["error_auprc"] is None or proposed["error_auprc"] is None else float(proposed["error_auprc"] - base["error_auprc"]),
        "aurc": float(proposed["aurc"] - base["aurc"]),
    }
    return out


def bootstrap_auprc_delta(
    *,
    y_true: np.ndarray,
    pred: np.ndarray,
    confidence: np.ndarray,
    audit_risk: np.ndarray,
    iterations: int,
    seed: int,
) -> dict[str, Any]:
    y_true = np.asarray(y_true, dtype=object)
    pred = np.asarray(pred, dtype=object)
    error = (pred != y_true).astype(np.int64)
    conf = 1.0 - np.asarray(confidence, dtype=np.float64)
    audit = np.asarray(audit_risk, dtype=np.float64)
    if len(np.unique(error)) < 2:
        return {"iterations": 0, "delta_auprc_ci95": None, "reason": "only one error class present"}
    rng = np.random.default_rng(seed)
    values = []
    n = len(error)
    for _ in range(int(iterations)):
        idx = rng.integers(0, n, size=n)
        if len(np.unique(error[idx])) < 2:
            continue
        values.append(float(average_precision_score(error[idx], audit[idx]) - average_precision_score(error[idx], conf[idx])))
    if not values:
        return {"iterations": 0, "delta_auprc_ci95": None, "reason": "bootstrap samples lacked both classes"}
    return {
        "iterations": int(len(values)),
        "delta_auprc_ci95": [float(np.quantile(values, 0.025)), float(np.quantile(values, 0.975))],
        "mean_delta_auprc": float(np.mean(values)),
    }
