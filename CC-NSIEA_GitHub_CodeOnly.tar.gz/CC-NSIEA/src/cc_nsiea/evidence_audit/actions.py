from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np


# The planner is intentionally constrained to evidence-retrieval actions only.
# None of these actions can emit or modify an activity label.
ALLOWED_ACTIONS: tuple[str, ...] = (
    "PREDICTED_CLASS_SUPPORT",
    "CLASS_CONTRAST",
    "MOTION_GROUP_CONTRAST",
    "PROTOTYPE_CONTRAST",
)


@dataclass(frozen=True)
class ActionView:
    action: str
    retrieval_support: float
    class_separation: float
    evidence_ids: list[int]
    description: str


def _clip01(x: float) -> float:
    return float(np.clip(float(x), 0.0, 1.0))


def _label_group(label: str) -> str:
    if label in {"walking", "walking_upstairs", "walking_downstairs"}:
        return "dynamic"
    if label in {"sitting", "standing", "laying"}:
        return "static"
    return "unknown"


def _neighbor_ids(rows: list[dict[str, Any]], limit: int) -> list[int]:
    return [int(row["source_index"]) for row in rows[: int(limit)]]


def _distance_support(rows: list[dict[str, Any]]) -> float:
    """Map cosine distances in [0, 2] to a bounded support score."""
    if not rows:
        return 0.0
    distances = np.asarray([float(row["cosine_distance"]) for row in rows], dtype=np.float64)
    return _clip01(float(np.mean(1.0 - distances / 2.0)))


def resolve_action_view(
    *,
    action: str,
    retrieval: dict[str, Any],
    labels: list[str],
    predicted_idx: int,
    competing_idx: int,
) -> ActionView:
    """Convert a guarded retrieval action into auditable numeric evidence.

    The raw neural prediction and the memory bank are fixed. The selected action
    only determines which already-retrieved evidence view is emphasized in
    round 1. This keeps the second-round evidence policy from acting as a label classifier.
    """
    if action not in ALLOWED_ACTIONS:
        raise ValueError(f"Unsupported evidence action: {action}")

    predicted_neighbors = list(retrieval["predicted_class_neighbors"])
    competing_neighbors = list(retrieval["competing_class_neighbors"])
    global_neighbors = list(retrieval["global_neighbors"])

    if action == "PREDICTED_CLASS_SUPPORT":
        support = 0.5 * float(retrieval["retrieval_agreement"]) + 0.5 * _distance_support(predicted_neighbors)
        separation = float(retrieval["nearest_neighbor_separation"])
        ids = _neighbor_ids(predicted_neighbors, len(predicted_neighbors))
        description = "Expanded nearest historical evidence from the neural predicted class."

    elif action == "CLASS_CONTRAST":
        support = float(retrieval["retrieval_agreement"])
        separation = float(retrieval["class_separation"])
        ids = _neighbor_ids(predicted_neighbors, len(predicted_neighbors)) + _neighbor_ids(competing_neighbors, len(competing_neighbors))
        description = "Contrasted predicted-class evidence against the top competing class."

    elif action == "MOTION_GROUP_CONTRAST":
        predicted_group = _label_group(labels[int(predicted_idx)])
        global_groups = [_label_group(labels[int(row["label_index"])]) for row in global_neighbors]
        group_agreement = float(np.mean(np.asarray(global_groups, dtype=object) == predicted_group)) if global_groups else 0.0
        competing_group = _label_group(labels[int(competing_idx)])
        # When the competitor is in the same motion group (e.g., sitting vs standing),
        # group-level retrieval cannot establish class separation; use the fixed class
        # separation instead of inventing a group advantage.
        if predicted_group == competing_group:
            group_separation = float(retrieval["class_separation"])
        else:
            group_separation = float(retrieval["nearest_neighbor_separation"])
        support = group_agreement
        separation = group_separation
        ids = _neighbor_ids(global_neighbors, len(global_neighbors))
        description = "Reviewed historical evidence for consistency with the predicted dynamic/static motion group."

    else:  # PROTOTYPE_CONTRAST
        proto_support = 1.0 - float(retrieval["prototype_predicted_distance"]) / 2.0
        support = _clip01(proto_support)
        separation = float(retrieval["prototype_separation"])
        ids = _neighbor_ids(predicted_neighbors, min(3, len(predicted_neighbors))) + _neighbor_ids(competing_neighbors, min(3, len(competing_neighbors)))
        description = "Compared the query embedding with predicted and competing class prototypes."

    # Preserve deterministic order while removing duplicates.
    deduped = list(dict.fromkeys(int(v) for v in ids))
    return ActionView(
        action=action,
        retrieval_support=_clip01(support),
        class_separation=_clip01(separation),
        evidence_ids=deduped,
        description=description,
    )


def action_catalog() -> dict[str, str]:
    return {
        "PREDICTED_CLASS_SUPPORT": "Retrieve additional nearest historical samples from the neural predicted class.",
        "CLASS_CONTRAST": "Retrieve and contrast evidence from the neural predicted class and its top competing class.",
        "MOTION_GROUP_CONTRAST": "Retrieve evidence emphasizing dynamic/static motion-group compatibility.",
        "PROTOTYPE_CONTRAST": "Retrieve prototype-oriented evidence for the predicted and competing classes.",
    }
