from __future__ import annotations

import json
from pathlib import Path
from typing import Any

REQUIRED_KPC_FIELDS = {
    "sample_id",
    "fold",
    "subject_id",
    "label_source",
    "override_permitted",
    "predicted_label",
    "top_competing_class",
    "confidence",
    "entropy",
    "iteration_count",
    "retrieval_rounds",
    "rule_results",
    "tau_history",
    "evidence_gain",
    "audit_risk",
    "audit_status",
    "stop_reason",
    "recommended_action",
}


def write_jsonl(path: str | Path, records: list[dict[str, Any]]) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        for record in records:
            f.write(json.dumps(record, ensure_ascii=False, sort_keys=True) + "\n")


def read_jsonl(path: str | Path) -> list[dict[str, Any]]:
    rows = []
    with Path(path).open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def kpc_completeness(records: list[dict[str, Any]]) -> dict[str, Any]:
    if not records:
        return {"n_records": 0, "complete_records": 0, "completeness_rate": 0.0, "missing_fields": {}}
    missing_counts: dict[str, int] = {}
    complete = 0
    for row in records:
        missing = [key for key in REQUIRED_KPC_FIELDS if key not in row or row[key] is None]
        if not missing:
            complete += 1
        for key in missing:
            missing_counts[key] = missing_counts.get(key, 0) + 1
        if row.get("override_permitted") is not False:
            missing_counts["override_permitted_not_false"] = missing_counts.get("override_permitted_not_false", 0) + 1
        if row.get("label_source") != "neural_temporal_resnet":
            missing_counts["unexpected_label_source"] = missing_counts.get("unexpected_label_source", 0) + 1
    return {
        "n_records": int(len(records)),
        "complete_records": int(complete),
        "completeness_rate": float(complete / len(records)),
        "missing_fields": missing_counts,
    }
