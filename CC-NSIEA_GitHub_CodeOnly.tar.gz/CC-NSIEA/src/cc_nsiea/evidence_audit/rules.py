from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np


DYNAMIC_LABELS = {"walking", "walking_upstairs", "walking_downstairs"}
STATIC_LABELS = {"sitting", "standing", "laying"}


@dataclass(frozen=True)
class MotionEnergyRule:
    boundary: float
    scale: float


def motion_energy(X: np.ndarray) -> np.ndarray:
    """Deterministic normalized body-motion energy from 9-channel input.

    Channels 3:6 are body acceleration in the common UCI/WISDM representation.
    The feature is a scalar audit signal only; it is not a label classifier.
    """
    X = np.asarray(X, dtype=np.float32)
    if X.ndim != 3 or X.shape[1] < 6:
        raise ValueError("Expected [N, >=6, T] sensor array.")
    body = X[:, 3:6, :]
    return np.sqrt(np.mean(np.square(body), axis=(1, 2))).astype(np.float32)


def fit_motion_energy_rule(X_memory: np.ndarray, labels: np.ndarray) -> MotionEnergyRule:
    labels = np.asarray(labels, dtype=object)
    energy = motion_energy(X_memory)
    dyn = energy[np.isin(labels, list(DYNAMIC_LABELS))]
    sta = energy[np.isin(labels, list(STATIC_LABELS))]
    if len(dyn) == 0 or len(sta) == 0:
        raise RuntimeError("Both dynamic and static classes are required for the motion-energy audit rule.")
    dyn_mean = float(np.mean(dyn))
    sta_mean = float(np.mean(sta))
    boundary = (dyn_mean + sta_mean) / 2.0
    scale = max(float(np.std(np.concatenate([dyn, sta]))), 1e-6)
    return MotionEnergyRule(boundary=boundary, scale=scale)


def _sigmoid(x: float) -> float:
    return float(1.0 / (1.0 + np.exp(-np.clip(x, -30.0, 30.0))))


def data_validity_rule(x: np.ndarray) -> dict[str, Any]:
    x = np.asarray(x)
    finite = bool(np.isfinite(x).all())
    # A simple outlier guard, evaluated in standardized sensor space.
    peak = float(np.max(np.abs(x))) if finite else float("inf")
    valid = finite and peak <= 30.0
    return {
        "rule_name": "data_validity",
        "score": 1.0 if valid else 0.0,
        "status": "valid" if valid else "data_validity_conflict",
        "evidence": {"all_finite": finite, "max_abs_value": peak},
    }


def motion_group_rule(x: np.ndarray, predicted_label: str, fitted: MotionEnergyRule) -> dict[str, Any]:
    energy = float(motion_energy(np.asarray(x, dtype=np.float32).reshape(1, *x.shape))[0])
    dynamic_probability = _sigmoid((energy - fitted.boundary) / fitted.scale)
    if predicted_label in DYNAMIC_LABELS:
        score = dynamic_probability
        expected_group = "dynamic"
    elif predicted_label in STATIC_LABELS:
        score = 1.0 - dynamic_probability
        expected_group = "static"
    else:
        raise ValueError(f"Unsupported activity label: {predicted_label}")
    return {
        "rule_name": "motion_group_coherence",
        "score": float(score),
        "status": "consistent" if score >= 0.5 else "conflict",
        "evidence": {
            "predicted_group": expected_group,
            "motion_energy": energy,
            "dynamic_motion_probability": dynamic_probability,
            "boundary": float(fitted.boundary),
        },
    }


def retrieval_support_rule(retrieval: dict[str, Any]) -> dict[str, Any]:
    score = float(retrieval["retrieval_agreement"])
    return {
        "rule_name": "retrieval_support",
        "score": score,
        "status": "supported" if score >= 0.6 else "weak_support",
        "evidence": {"top_k_global": int(retrieval["top_k_global"]), "agreement": score},
    }


def contrastive_separation_rule(retrieval: dict[str, Any], competing_label: str) -> dict[str, Any]:
    score = float(retrieval["class_separation"])
    return {
        "rule_name": "contrastive_separation",
        "score": score,
        "status": "separated" if score >= 0.25 else "ambiguous",
        "evidence": {
            "competing_label": str(competing_label),
            "nearest_predicted_distance": float(retrieval["nearest_predicted_distance"]),
            "nearest_competing_distance": float(retrieval["nearest_competing_distance"]),
            "prototype_predicted_distance": float(retrieval["prototype_predicted_distance"]),
            "prototype_competing_distance": float(retrieval["prototype_competing_distance"]),
        },
    }


def evaluate_rules(
    x: np.ndarray,
    predicted_label: str,
    competing_label: str,
    retrieval: dict[str, Any],
    motion_rule: MotionEnergyRule,
) -> list[dict[str, Any]]:
    return [
        data_validity_rule(x),
        motion_group_rule(x, predicted_label, motion_rule),
        retrieval_support_rule(retrieval),
        contrastive_separation_rule(retrieval, competing_label),
    ]
