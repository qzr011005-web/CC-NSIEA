from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np
from sklearn.metrics import average_precision_score

from .retrieval import EvidenceMemory, retrieve_round
from .rules import MotionEnergyRule, evaluate_rules


@dataclass(frozen=True)
class AuditControllerConfig:
    round0_top_k_global: int
    round1_top_k_global: int
    top_k_class_conditioned: int
    max_iterations: int
    evidence_gain_epsilon: float
    tau_stop: float
    aggregation_weights: dict[str, float]


def _normalise_weights(weights: dict[str, float]) -> dict[str, float]:
    expected = {"confidence", "retrieval_support", "class_separation", "rule_consistency"}
    if set(weights) != expected:
        raise ValueError(f"Aggregation weights must have keys {sorted(expected)}.")
    total = float(sum(weights.values()))
    if total <= 0:
        raise ValueError("Aggregation weights must sum to a positive value.")
    return {k: float(v) / total for k, v in weights.items()}


def _top_competing_index(probabilities: np.ndarray, predicted_idx: int) -> int:
    order = np.argsort(-probabilities, kind="stable")
    for idx in order:
        if int(idx) != int(predicted_idx):
            return int(idx)
    raise RuntimeError("A competing class is required for evidence auditing.")


def _tau(confidence: float, retrieval_support: float, class_separation: float, rule_consistency: float, weights: dict[str, float]) -> float:
    return float(np.clip(
        weights["confidence"] * confidence
        + weights["retrieval_support"] * retrieval_support
        + weights["class_separation"] * class_separation
        + weights["rule_consistency"] * rule_consistency,
        0.0,
        1.0,
    ))


class EvidenceAuditController:
    """Read-only Retrieve–Reason–Refine controller.

    The controller never creates a revised label. It may request a second,
    larger contrastive evidence retrieval round when the first-round evidence
    sufficiency is below tau_stop.
    """

    def __init__(
        self,
        memory: EvidenceMemory,
        motion_rule: MotionEnergyRule,
        labels: list[str],
        cfg: AuditControllerConfig,
    ) -> None:
        self.memory = memory
        self.motion_rule = motion_rule
        self.labels = list(labels)
        self.cfg = cfg
        self.weights = _normalise_weights(cfg.aggregation_weights)
        if cfg.max_iterations != 2:
            raise ValueError("This preregistered controller supports exactly two evidence rounds.")
        if cfg.round1_top_k_global < cfg.round0_top_k_global:
            raise ValueError("Round-1 retrieval must not use fewer global neighbors than round 0.")

    def _run_round(
        self,
        *,
        x: np.ndarray,
        embedding: np.ndarray,
        probabilities: np.ndarray,
        predicted_idx: int,
        competing_idx: int,
        global_k: int,
        round_id: int,
    ) -> dict[str, Any]:
        pred_label = self.labels[int(predicted_idx)]
        comp_label = self.labels[int(competing_idx)]
        retrieval = retrieve_round(
            embedding,
            predicted_idx,
            competing_idx,
            self.memory,
            top_k_global=global_k,
            top_k_class_conditioned=self.cfg.top_k_class_conditioned,
        )
        rules = evaluate_rules(x, pred_label, comp_label, retrieval, self.motion_rule)
        validity = next(row for row in rules if row["rule_name"] == "data_validity")
        motion = next(row for row in rules if row["rule_name"] == "motion_group_coherence")
        rule_consistency = float((float(validity["score"]) + float(motion["score"])) / 2.0)
        confidence = float(np.max(probabilities))
        tau = _tau(
            confidence,
            float(retrieval["retrieval_agreement"]),
            float(retrieval["class_separation"]),
            rule_consistency,
            self.weights,
        )
        return {
            "round": int(round_id),
            "predicted_label": pred_label,
            "competing_label": comp_label,
            "confidence_support": confidence,
            "retrieval_support": float(retrieval["retrieval_agreement"]),
            "class_separation": float(retrieval["class_separation"]),
            "rule_consistency": rule_consistency,
            "tau": tau,
            "retrieval": retrieval,
            "rule_results": rules,
            "data_valid": bool(validity["status"] == "valid"),
        }

    def audit_one(
        self,
        *,
        sample_id: int,
        subject_id: int,
        x: np.ndarray,
        embedding: np.ndarray,
        probabilities: np.ndarray,
        ground_truth: str | None = None,
        fold: int | None = None,
    ) -> dict[str, Any]:
        probabilities = np.asarray(probabilities, dtype=np.float64)
        predicted_idx = int(np.argmax(probabilities))
        competing_idx = _top_competing_index(probabilities, predicted_idx)
        round0 = self._run_round(
            x=x,
            embedding=embedding,
            probabilities=probabilities,
            predicted_idx=predicted_idx,
            competing_idx=competing_idx,
            global_k=self.cfg.round0_top_k_global,
            round_id=0,
        )
        rounds = [round0]
        tau_history = [float(round0["tau"])]
        evidence_gain = 0.0

        if not round0["data_valid"]:
            stop_reason = "data_validity_conflict"
            final = round0
        elif round0["tau"] >= self.cfg.tau_stop:
            stop_reason = "sufficient_evidence"
            final = round0
        else:
            round1 = self._run_round(
                x=x,
                embedding=embedding,
                probabilities=probabilities,
                predicted_idx=predicted_idx,
                competing_idx=competing_idx,
                global_k=self.cfg.round1_top_k_global,
                round_id=1,
            )
            rounds.append(round1)
            tau_history.append(float(round1["tau"]))
            evidence_gain = float(round1["tau"] - round0["tau"])
            final = round1
            if evidence_gain < self.cfg.evidence_gain_epsilon:
                stop_reason = "no_evidence_gain"
            elif round1["tau"] >= self.cfg.tau_stop:
                stop_reason = "sufficient_evidence"
            else:
                stop_reason = "max_iter_reached"

        risk = float(1.0 - final["tau"])
        if stop_reason == "data_validity_conflict":
            status = "data_conflict"
        elif stop_reason == "sufficient_evidence":
            status = "supported"
        else:
            status = "evidence_gap"

        entropy = float(-(probabilities * np.log(np.maximum(probabilities, 1e-12))).sum())
        record = {
            "sample_id": int(sample_id),
            "fold": None if fold is None else int(fold),
            "subject_id": int(subject_id),
            "label_source": "neural_temporal_resnet",
            "override_permitted": False,
            "predicted_label": self.labels[predicted_idx],
            "ground_truth_available_for_evaluation_only": None if ground_truth is None else str(ground_truth),
            "top_competing_class": self.labels[competing_idx],
            "confidence": float(np.max(probabilities)),
            "entropy": entropy,
            "iteration_count": int(len(rounds)),
            "retrieval_rounds": rounds,
            "rule_results": final["rule_results"],
            "tau_history": tau_history,
            "evidence_gain": evidence_gain,
            "audit_risk": risk,
            "audit_status": status,
            "stop_reason": stop_reason,
            "recommended_action": "accept_prediction" if status == "supported" else "human_review_or_additional_sensor_context",
        }
        return record

    def audit_batch(
        self,
        *,
        sample_ids: np.ndarray,
        subject_ids: np.ndarray,
        X: np.ndarray,
        embeddings: np.ndarray,
        probabilities: np.ndarray,
        ground_truth: np.ndarray | None = None,
        fold: int | None = None,
    ) -> list[dict[str, Any]]:
        records = []
        for i in range(len(sample_ids)):
            records.append(self.audit_one(
                sample_id=int(sample_ids[i]),
                subject_id=int(subject_ids[i]),
                x=X[i],
                embedding=embeddings[i],
                probabilities=probabilities[i],
                ground_truth=None if ground_truth is None else str(ground_truth[i]),
                fold=fold,
            ))
        return records


def _risk_from_records(records: list[dict[str, Any]]) -> np.ndarray:
    return np.asarray([float(row["audit_risk"]) for row in records], dtype=np.float64)


def calibrate_tau_threshold(
    *,
    controller_factory,
    calibration_inputs: dict[str, Any],
    tau_grid: list[float],
) -> tuple[float, dict[str, Any]]:
    """Select tau using only calibration subjects and error-detection AUPRC.

    No outer-test information is inspected. Ties prefer the lower threshold,
    which avoids choosing extra iterations without measured calibration gain.
    """
    y_true = np.asarray(calibration_inputs["ground_truth"], dtype=object)
    best = None
    rows = []
    for tau in sorted(float(v) for v in tau_grid):
        controller = controller_factory(float(tau))
        records = controller.audit_batch(**calibration_inputs)
        error = np.asarray([row["predicted_label"] != truth for row, truth in zip(records, y_true)], dtype=np.int64)
        risk = _risk_from_records(records)
        if len(np.unique(error)) < 2:
            auprc = float("nan")
        else:
            auprc = float(average_precision_score(error, risk))
        mean_iterations = float(np.mean([row["iteration_count"] for row in records]))
        row = {"tau_stop": tau, "calibration_error_auprc": auprc, "mean_iterations": mean_iterations}
        rows.append(row)
        score = -np.inf if np.isnan(auprc) else auprc
        candidate = (score, -mean_iterations, -tau, tau)
        if best is None or candidate > best[0]:
            best = (candidate, tau, row)
    if best is None:
        raise RuntimeError("No tau candidate was evaluated.")
    return float(best[1]), {"selection_metric": "calibration_error_auprc", "grid": rows, "selected": best[2]}
