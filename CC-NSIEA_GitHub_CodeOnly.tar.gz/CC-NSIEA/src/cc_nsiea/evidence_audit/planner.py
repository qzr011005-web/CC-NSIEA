from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, Protocol

from .actions import ALLOWED_ACTIONS


@dataclass(frozen=True)
class PlannerDecision:
    """Auditable decision for a whitelisted second-round evidence view."""

    action: str
    planner_type: str
    decision_status: str
    reason_code: str
    evidence_ids: list[int]
    prompt_hash: str | None = None
    response_hash: str | None = None
    cache_key: str | None = None
    cache_hit: bool = False
    api_latency_ms: float | None = None
    fallback_used: bool = False
    fallback_reason: str | None = None
    model: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class ActionPlanner(Protocol):
    def plan(self, state: dict[str, Any]) -> PlannerDecision:
        ...


class DeterministicActionPlanner:
    """Matched baseline controller for D-NSIEA.

    It chooses one of the predefined evidence views using only round-0
    audit values. It never accesses ground-truth labels and cannot alter
    the neural prediction, probabilities, or stopping logic.
    """

    def __init__(self, fallback_action: str = "CLASS_CONTRAST") -> None:
        if fallback_action not in ALLOWED_ACTIONS:
            raise ValueError("fallback_action must be an allowed action.")
        self.fallback_action = fallback_action

    def plan(self, state: dict[str, Any]) -> PlannerDecision:
        r0 = state["round0"]
        rules = {row["rule_name"]: row for row in r0["rule_results"]}
        if rules["motion_group_coherence"]["status"] == "conflict":
            action = "MOTION_GROUP_CONTRAST"
            reason = "motion_rule_conflict"
        elif float(r0["class_separation"]) < 0.25:
            action = "CLASS_CONTRAST"
            reason = "low_class_separation"
        elif float(r0["retrieval_support"]) < 0.60:
            action = "PREDICTED_CLASS_SUPPORT"
            reason = "weak_retrieval_support"
        else:
            action = "PROTOTYPE_CONTRAST"
            reason = "prototype_review"
        return PlannerDecision(
            action=action,
            planner_type="deterministic",
            decision_status="deterministic",
            reason_code=reason,
            evidence_ids=[],
        )


class FixedClassContrastPlanner:
    """CC-NSIEA refinement policy.

    Whenever the evidence-sufficiency controller triggers a second round,
    this planner uses the fixed CLASS_CONTRAST view. It has no API client,
    cache, or access to evaluation labels.
    """

    def plan(self, state: dict[str, Any]) -> PlannerDecision:
        return PlannerDecision(
            action="CLASS_CONTRAST",
            planner_type="fixed_class_contrast",
            decision_status="fixed_class_contrast",
            reason_code="fixed_class_contrast_policy",
            evidence_ids=[],
        )
