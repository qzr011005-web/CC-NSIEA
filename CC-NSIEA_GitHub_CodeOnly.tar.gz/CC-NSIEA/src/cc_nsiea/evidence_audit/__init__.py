"""Label-preserving neuro-symbolic evidence audit for wearable HAR.

The package contains the matched dynamic deterministic baseline (D-NSIEA) and
the final fixed class-contrast controller (CC-NSIEA). Both receive identical
neural predictions, evidence memory, rules, and calibrated stopping thresholds.
Neither controller can create or override an activity label.
"""

from .controller import EvidenceAuditController, calibrate_tau_threshold
from .guided_controller import GuidedAuditControllerConfig, GuidedEvidenceAuditController
from .metrics import evaluate_risk_estimators
from .planner import DeterministicActionPlanner, FixedClassContrastPlanner

__all__ = [
    "EvidenceAuditController",
    "GuidedAuditControllerConfig",
    "GuidedEvidenceAuditController",
    "DeterministicActionPlanner",
    "FixedClassContrastPlanner",
    "calibrate_tau_threshold",
    "evaluate_risk_estimators",
]
