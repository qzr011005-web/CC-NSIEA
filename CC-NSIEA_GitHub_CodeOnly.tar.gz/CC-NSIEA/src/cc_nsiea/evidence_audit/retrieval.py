from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np


@dataclass(frozen=True)
class EvidenceMemory:
    embeddings: np.ndarray
    labels_idx: np.ndarray
    source_indices: np.ndarray
    subject_ids: np.ndarray
    class_prototypes: np.ndarray


def _l2_normalize(x: np.ndarray) -> np.ndarray:
    x = np.asarray(x, dtype=np.float32)
    denom = np.linalg.norm(x, axis=1, keepdims=True)
    return x / np.maximum(denom, 1e-12)


def build_evidence_memory(
    embeddings: np.ndarray,
    labels_idx: np.ndarray,
    source_indices: np.ndarray,
    subject_ids: np.ndarray,
    num_classes: int,
) -> EvidenceMemory:
    embeddings = _l2_normalize(embeddings)
    labels_idx = np.asarray(labels_idx, dtype=np.int64)
    source_indices = np.asarray(source_indices, dtype=np.int64)
    subject_ids = np.asarray(subject_ids, dtype=np.int64)
    if not (len(embeddings) == len(labels_idx) == len(source_indices) == len(subject_ids)):
        raise ValueError("Evidence memory arrays must have matching lengths.")
    prototypes = []
    for class_idx in range(int(num_classes)):
        selected = embeddings[labels_idx == class_idx]
        if len(selected) == 0:
            raise RuntimeError(f"No evidence memory samples for class index {class_idx}.")
        proto = selected.mean(axis=0, keepdims=True)
        prototypes.append(_l2_normalize(proto)[0])
    return EvidenceMemory(
        embeddings=embeddings,
        labels_idx=labels_idx,
        source_indices=source_indices,
        subject_ids=subject_ids,
        class_prototypes=np.stack(prototypes).astype(np.float32),
    )


def _neighbor_rows(distances: np.ndarray, memory: EvidenceMemory, limit: int) -> list[dict[str, Any]]:
    idx = np.argsort(distances, kind="stable")[: int(limit)]
    return [
        {
            "source_index": int(memory.source_indices[j]),
            "subject_id": int(memory.subject_ids[j]),
            "label_index": int(memory.labels_idx[j]),
            "cosine_distance": float(distances[j]),
        }
        for j in idx
    ]


def retrieve_round(
    query_embedding: np.ndarray,
    predicted_idx: int,
    competing_idx: int,
    memory: EvidenceMemory,
    *,
    top_k_global: int,
    top_k_class_conditioned: int,
) -> dict[str, Any]:
    """Retrieve same-class, competitor-class, and global support evidence.

    Retrieval is completely read-only: `predicted_idx` is carried through as an
    input and never recomputed from neighbors or rules.
    """
    query = _l2_normalize(np.asarray(query_embedding, dtype=np.float32).reshape(1, -1))[0]
    global_dist = np.clip(1.0 - memory.embeddings @ query, 0.0, 2.0)
    pred_mask = memory.labels_idx == int(predicted_idx)
    comp_mask = memory.labels_idx == int(competing_idx)
    if not pred_mask.any() or not comp_mask.any():
        raise RuntimeError("Predicted or competing class is absent from the evidence memory.")

    pred_dist = global_dist.copy()
    pred_dist[~pred_mask] = np.inf
    comp_dist = global_dist.copy()
    comp_dist[~comp_mask] = np.inf

    global_idx = np.argsort(global_dist, kind="stable")[: int(top_k_global)]
    agreement = float(np.mean(memory.labels_idx[global_idx] == int(predicted_idx)))
    d_pred = float(np.min(pred_dist))
    d_comp = float(np.min(comp_dist))
    separation = float(np.clip((d_comp - d_pred) / max(d_comp + 1e-12, 1e-12), 0.0, 1.0))

    proto_dist = np.clip(1.0 - memory.class_prototypes @ query, 0.0, 2.0)
    proto_pred = float(proto_dist[int(predicted_idx)])
    proto_comp = float(proto_dist[int(competing_idx)])
    proto_separation = float(np.clip((proto_comp - proto_pred) / max(proto_comp + 1e-12, 1e-12), 0.0, 1.0))
    combined_separation = float((separation + proto_separation) / 2.0)

    return {
        "top_k_global": int(top_k_global),
        "top_k_class_conditioned": int(top_k_class_conditioned),
        "global_neighbors": _neighbor_rows(global_dist, memory, top_k_global),
        "predicted_class_neighbors": _neighbor_rows(pred_dist, memory, top_k_class_conditioned),
        "competing_class_neighbors": _neighbor_rows(comp_dist, memory, top_k_class_conditioned),
        "retrieval_agreement": agreement,
        "nearest_predicted_distance": d_pred,
        "nearest_competing_distance": d_comp,
        "nearest_neighbor_separation": separation,
        "prototype_predicted_distance": proto_pred,
        "prototype_competing_distance": proto_comp,
        "prototype_separation": proto_separation,
        "class_separation": combined_separation,
    }
