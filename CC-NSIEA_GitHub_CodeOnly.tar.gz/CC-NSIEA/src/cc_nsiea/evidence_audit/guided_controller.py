from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np

from .actions import resolve_action_view
from .controller import AuditControllerConfig, _normalise_weights, _tau, _top_competing_index
from .planner import ActionPlanner
from .retrieval import EvidenceMemory, retrieve_round
from .rules import MotionEnergyRule, evaluate_rules


@dataclass(frozen=True)
class GuidedAuditControllerConfig(AuditControllerConfig):
    """Same fixed audit parameters as D-NSIEA; planner only changes the predefined round-1 evidence view."""


class GuidedEvidenceAuditController:
    """Label-preserving controller with deterministic evidence-action planning.

    Deterministic stopping remains authoritative. The action planner is invoked only
    after round 0 is insufficient and only chooses one whitelisted round-1 evidence
    retrieval view. No planner output can alter labels, probabilities, or stopping logic.
    """

    def __init__(
        self,
        *,
        memory: EvidenceMemory,
        motion_rule: MotionEnergyRule,
        labels: list[str],
        cfg: GuidedAuditControllerConfig,
        planner: ActionPlanner,
        controller_name: str,
    ) -> None:
        self.memory = memory
        self.motion_rule = motion_rule
        self.labels = list(labels)
        self.cfg = cfg
        self.planner = planner
        self.controller_name = str(controller_name)
        self.weights = _normalise_weights(cfg.aggregation_weights)
        if cfg.max_iterations != 2:
            raise ValueError("Guided controller supports exactly two evidence rounds.")
        if cfg.round1_top_k_global < cfg.round0_top_k_global:
            raise ValueError("Round-1 retrieval must not use fewer global neighbors than round 0.")

    def _round(
        self,
        *,
        x: np.ndarray,
        embedding: np.ndarray,
        probabilities: np.ndarray,
        predicted_idx: int,
        competing_idx: int,
        global_k: int,
        round_id: int,
        action: str | None = None,
    ) -> dict[str, Any]:
        pred_label = self.labels[int(predicted_idx)]
        comp_label = self.labels[int(competing_idx)]
        retrieval = retrieve_round(
            embedding,
            predicted_idx,
            competing_idx,
            self.memory,
            top_k_global=global_k,
            top_k_class_conditioned=self.cfg.top_k_class_conditioned,
        )
        if action is None:
            support = float(retrieval["retrieval_agreement"])
            separation = float(retrieval["class_separation"])
            action_view = {
                "action": "INITIAL_GLOBAL",
                "retrieval_support": support,
                "class_separation": separation,
                "evidence_ids": [int(r["source_index"]) for r in retrieval["global_neighbors"]],
                "description": "Initial global historical-evidence retrieval.",
            }
        else:
            view = resolve_action_view(
                action=action,
                retrieval=retrieval,
                labels=self.labels,
                predicted_idx=predicted_idx,
                competing_idx=competing_idx,
            )
            support = float(view.retrieval_support)
            separation = float(view.class_separation)
            action_view = {
                "action": view.action,
                "retrieval_support": support,
                "class_separation": separation,
                "evidence_ids": view.evidence_ids,
                "description": view.description,
            }

        retrieval_for_rules = dict(retrieval)
        retrieval_for_rules["retrieval_agreement"] = support
        retrieval_for_rules["class_separation"] = separation
        rules = evaluate_rules(x, pred_label, comp_label, retrieval_for_rules, self.motion_rule)
        validity = next(row for row in rules if row["rule_name"] == "data_validity")
        motion = next(row for row in rules if row["rule_name"] == "motion_group_coherence")
        rule_consistency = float((float(validity["score"]) + float(motion["score"])) / 2.0)
        confidence = float(np.max(probabilities))
        tau = _tau(confidence, support, separation, rule_consistency, self.weights)
        return {
            "round": int(round_id),
            "predicted_label": pred_label,
            "competing_label": comp_label,
            "confidence_support": confidence,
            "retrieval_support": support,
            "class_separation": separation,
            "rule_consistency": rule_consistency,
            "tau": tau,
            "retrieval": retrieval,
            "action_view": action_view,
            "rule_results": rules,
            "data_valid": bool(validity["status"] == "valid"),
        }

    def audit_one(
        self,
        *,
        sample_id: int,
        subject_id: int,
        x: np.ndarray,
        embedding: np.ndarray,
        probabilities: np.ndarray,
        ground_truth: str | None = None,
        fold: int | None = None,
    ) -> dict[str, Any]:
        probabilities = np.asarray(probabilities, dtype=np.float64)
        predicted_idx = int(np.argmax(probabilities))
        competing_idx = _top_competing_index(probabilities, predicted_idx)
        round0 = self._round(
            x=x, embedding=embedding, probabilities=probabilities,
            predicted_idx=predicted_idx, competing_idx=competing_idx,
            global_k=self.cfg.round0_top_k_global, round_id=0,
        )
        rounds = [round0]
        tau_history = [float(round0["tau"])]
        evidence_gain = 0.0
        planner_decision = None

        if not round0["data_valid"]:
            stop_reason = "data_validity_conflict"
            final = round0
        elif round0["tau"] >= self.cfg.tau_stop:
            stop_reason = "sufficient_evidence"
            final = round0
        else:
            planner_state = {
                "sample_id": int(sample_id),
                "fold": -1 if fold is None else int(fold),
                "predicted_label": self.labels[predicted_idx],
                "competing_label": self.labels[competing_idx],
                "round0": round0,
            }
            planner_decision = self.planner.plan(planner_state)
            round1 = self._round(
                x=x, embedding=embedding, probabilities=probabilities,
                predicted_idx=predicted_idx, competing_idx=competing_idx,
                global_k=self.cfg.round1_top_k_global, round_id=1,
                action=planner_decision.action,
            )
            rounds.append(round1)
            tau_history.append(float(round1["tau"]))
            evidence_gain = float(round1["tau"] - round0["tau"])
            final = round1
            if evidence_gain < self.cfg.evidence_gain_epsilon:
                stop_reason = "no_evidence_gain"
            elif round1["tau"] >= self.cfg.tau_stop:
                stop_reason = "sufficient_evidence"
            else:
                stop_reason = "max_iter_reached"

        risk = float(1.0 - final["tau"])
        if stop_reason == "data_validity_conflict":
            status = "data_conflict"
        elif stop_reason == "sufficient_evidence":
            status = "supported"
        else:
            status = "evidence_gap"
        entropy = float(-(probabilities * np.log(np.maximum(probabilities, 1e-12))).sum())

        record = {
            "sample_id": int(sample_id),
            "fold": None if fold is None else int(fold),
            "subject_id": int(subject_id),
            "controller_name": self.controller_name,
            "label_source": "neural_temporal_resnet",
            "override_permitted": False,
            "predicted_label": self.labels[predicted_idx],
            "ground_truth_available_for_evaluation_only": None if ground_truth is None else str(ground_truth),
            "top_competing_class": self.labels[competing_idx],
            "confidence": float(np.max(probabilities)),
            "entropy": entropy,
            "iteration_count": int(len(rounds)),
            "retrieval_rounds": rounds,
            "rule_results": final["rule_results"],
            "tau_history": tau_history,
            "evidence_gain": evidence_gain,
            "audit_risk": risk,
            "audit_status": status,
            "stop_reason": stop_reason,
            "recommended_action": "accept_prediction" if status == "supported" else "human_review_or_additional_sensor_context",
            "planner_decision": None if planner_decision is None else planner_decision.to_dict(),
            "planner_invoked": bool(planner_decision is not None),
            "round1_action": None if planner_decision is None else planner_decision.action,
        }
        return record

    def audit_batch(
        self,
        *,
        sample_ids: np.ndarray,
        subject_ids: np.ndarray,
        X: np.ndarray,
        embeddings: np.ndarray,
        probabilities: np.ndarray,
        ground_truth: np.ndarray | None = None,
        fold: int | None = None,
    ) -> list[dict[str, Any]]:
        out: list[dict[str, Any]] = []
        for i in range(len(sample_ids)):
            out.append(self.audit_one(
                sample_id=int(sample_ids[i]),
                subject_id=int(subject_ids[i]),
                x=X[i],
                embedding=embeddings[i],
                probabilities=probabilities[i],
                ground_truth=None if ground_truth is None else str(ground_truth[i]),
                fold=fold,
            ))
        return out
