\
from __future__ import annotations

import hashlib
import json
import os
import re
import time
from pathlib import Path
from typing import Any

from ..evidence_audit.actions import ALLOWED_ACTIONS, action_catalog
from ..evidence_audit.planner import PlannerDecision


def _canonical_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def _sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _extract_json_object(text: str) -> dict[str, Any]:
    """Parse a constrained JSON response without accepting free-form output."""
    text = text.strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\s*", "", text, flags=re.IGNORECASE)
        text = re.sub(r"\s*```$", "", text)
    try:
        parsed = json.loads(text)
    except json.JSONDecodeError:
        match = re.search(r"\{.*\}", text, flags=re.DOTALL)
        if not match:
            raise
        parsed = json.loads(match.group(0))
    if not isinstance(parsed, dict):
        raise ValueError("Planner response must be a JSON object.")
    return parsed


def _validate_response(response: dict[str, Any], allowed_evidence_ids: set[int]) -> tuple[str, str, list[int]]:
    # The diagnostic planner must not emit a revised label, label confidence,
    # or any other label-bearing field.
    forbidden = {"label", "predicted_label", "revised_label", "final_prediction", "new_label", "classification"}
    if forbidden.intersection(response):
        raise ValueError("Planner attempted to emit a label-bearing field.")
    action = str(response.get("action", "")).strip()
    if action not in ALLOWED_ACTIONS:
        raise ValueError(f"Invalid planner action: {action!r}")
    reason_code = str(response.get("reason_code", "unspecified")).strip()[:120] or "unspecified"
    ids = response.get("evidence_ids", [])
    if ids is None:
        ids = []
    if not isinstance(ids, list) or any(not isinstance(v, int) for v in ids):
        raise ValueError("evidence_ids must be a JSON list of integers.")
    ids = [int(v) for v in ids]
    if any(v not in allowed_evidence_ids for v in ids):
        raise ValueError("Planner referenced evidence IDs not present in round-0 retrieval.")
    return action, reason_code, list(dict.fromkeys(ids))


class LLMActionPlanner:
    """Constrained external action planner used only as a diagnostic control.

    The planner receives no ground-truth label and may select only a predefined
    second-round evidence view. It cannot alter the neural label, posterior
    probabilities, or deterministic stopping logic. API failures and malformed
    output use deterministic fallback.
    """

    def __init__(
        self,
        *,
        model: str,
        base_url: str,
        api_key_env: str,
        temperature: float,
        max_tokens: int,
        timeout_seconds: float,
        max_retries: int,
        cache_dir: str | Path,
        cache_mode: str,
        max_live_calls: int,
        fallback_action: str,
    ) -> None:
        if cache_mode not in {"read_write", "read_only", "disabled"}:
            raise ValueError("cache_mode must be one of read_write/read_only/disabled.")
        if fallback_action not in ALLOWED_ACTIONS:
            raise ValueError("fallback_action must be an allowed action.")
        self.model = str(model)
        self.base_url = str(base_url)
        self.api_key_env = str(api_key_env)
        self.temperature = float(temperature)
        self.max_tokens = int(max_tokens)
        self.timeout_seconds = float(timeout_seconds)
        self.max_retries = int(max_retries)
        self.cache_dir = Path(cache_dir)
        self.cache_mode = str(cache_mode)
        self.max_live_calls = int(max_live_calls)
        self.fallback_action = str(fallback_action)
        self.live_calls = 0
        self.cache_hits = 0
        self.fallbacks = 0

    def _fallback(self, *, status: str, reason: str, prompt_hash: str | None = None, cache_key: str | None = None) -> PlannerDecision:
        self.fallbacks += 1
        return PlannerDecision(
            action=self.fallback_action,
            planner_type="llm_diagnostic",
            decision_status=status,
            reason_code="deterministic_fallback",
            evidence_ids=[],
            prompt_hash=prompt_hash,
            response_hash=None,
            cache_key=cache_key,
            cache_hit=False,
            api_latency_ms=None,
            fallback_used=True,
            fallback_reason=reason,
            model=self.model,
        )

    def _make_prompt(self, state: dict[str, Any]) -> tuple[str, dict[str, Any]]:
        r0 = state["round0"]
        retrieval = r0["retrieval"]
        neighbor_rows = [
            {
                "evidence_id": int(row["source_index"]),
                "label_index": int(row["label_index"]),
                "cosine_distance": round(float(row["cosine_distance"]), 6),
            }
            for row in retrieval["global_neighbors"]
        ]
        rule_rows = [
            {"rule_name": str(row["rule_name"]), "status": str(row["status"]), "score": round(float(row["score"]), 6)}
            for row in r0["rule_results"]
        ]
        context = {
            "schema_version": "llm_action_planner_v1",
            "sample_id": int(state["sample_id"]),
            "fold": int(state["fold"]),
            "neural_prediction": str(state["predicted_label"]),
            "top_competing_class": str(state["competing_label"]),
            "confidence": round(float(r0["confidence_support"]), 6),
            "tau_round0": round(float(r0["tau"]), 6),
            "retrieval_support": round(float(r0["retrieval_support"]), 6),
            "class_separation": round(float(r0["class_separation"]), 6),
            "rule_results": rule_rows,
            "round0_evidence": neighbor_rows,
            "allowed_actions": action_catalog(),
            "allowed_evidence_ids": [row["evidence_id"] for row in neighbor_rows],
        }
        system = (
            "You are a constrained evidence-retrieval planner for wearable-sensor activity recognition. "
            "You are not a classifier. You must never revise, output, rank, or change an activity label. "
            "You may only choose one allowed retrieval action based on the supplied round-0 evidence summary. "
            "Return JSON only, exactly with keys: action, reason_code, evidence_ids. "
            "evidence_ids must be a subset of allowed_evidence_ids."
        )
        prompt = _canonical_json({"system": system, "user": _canonical_json(context)})
        return prompt, context

    def _cache_path(self, cache_key: str) -> Path:
        return self.cache_dir / f"{cache_key}.json"

    def _read_cache(self, cache_key: str) -> dict[str, Any] | None:
        path = self._cache_path(cache_key)
        if not path.exists():
            return None
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            return None

    def _write_cache(self, cache_key: str, payload: dict[str, Any]) -> None:
        path = self._cache_path(cache_key)
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_suffix(".tmp")
        temporary.write_text(json.dumps(payload, ensure_ascii=False, sort_keys=True, indent=2), encoding="utf-8")
        temporary.replace(path)

    def _live_request(self, prompt: str) -> tuple[str, float]:
        api_key = os.getenv(self.api_key_env, "").strip()
        if not api_key:
            raise RuntimeError(f"Missing environment variable {self.api_key_env}.")
        try:
            from openai import OpenAI
        except ImportError as exc:
            raise RuntimeError("The optional 'openai' package is not installed.") from exc
        client = OpenAI(api_key=api_key, base_url=self.base_url, timeout=self.timeout_seconds)
        request = json.loads(prompt)
        started = time.perf_counter()
        last_error: Exception | None = None
        for attempt in range(self.max_retries + 1):
            try:
                response = client.chat.completions.create(
                    model=self.model,
                    messages=[
                        {"role": "system", "content": request["system"]},
                        {"role": "user", "content": request["user"]},
                    ],
                    temperature=self.temperature,
                    max_tokens=self.max_tokens,
                )
                content = response.choices[0].message.content
                if content is None:
                    raise RuntimeError("Planner returned empty content.")
                return str(content), (time.perf_counter() - started) * 1000.0
            except Exception as exc:
                last_error = exc
                if attempt >= self.max_retries:
                    break
        assert last_error is not None
        raise last_error

    def plan(self, state: dict[str, Any]) -> PlannerDecision:
        prompt, context = self._make_prompt(state)
        prompt_hash = _sha256_text(prompt)
        cache_key = prompt_hash
        allowed_ids = set(int(v) for v in context["allowed_evidence_ids"])

        cached = self._read_cache(cache_key)
        if cached is not None:
            try:
                response_text = str(cached["response_text"])
                parsed = _extract_json_object(response_text)
                action, reason_code, evidence_ids = _validate_response(parsed, allowed_ids)
                self.cache_hits += 1
                return PlannerDecision(
                    action=action,
                    planner_type="llm_diagnostic",
                    decision_status="cache_hit",
                    reason_code=reason_code,
                    evidence_ids=evidence_ids,
                    prompt_hash=prompt_hash,
                    response_hash=_sha256_text(response_text),
                    cache_key=cache_key,
                    cache_hit=True,
                    api_latency_ms=float(cached.get("api_latency_ms")) if cached.get("api_latency_ms") is not None else None,
                    fallback_used=False,
                    fallback_reason=None,
                    model=self.model,
                )
            except Exception as exc:
                return self._fallback(status="cache_invalid_fallback", reason=f"{type(exc).__name__}: {exc}", prompt_hash=prompt_hash, cache_key=cache_key)

        if self.cache_mode == "read_only":
            return self._fallback(status="cache_miss_fallback", reason="cache_mode_read_only", prompt_hash=prompt_hash, cache_key=cache_key)
        if self.cache_mode == "disabled":
            return self._fallback(status="llm_disabled_fallback", reason="cache_mode_disabled", prompt_hash=prompt_hash, cache_key=cache_key)
        if self.live_calls >= self.max_live_calls:
            return self._fallback(status="budget_fallback", reason="max_live_calls_reached", prompt_hash=prompt_hash, cache_key=cache_key)

        try:
            response_text, latency = self._live_request(prompt)
            parsed = _extract_json_object(response_text)
            action, reason_code, evidence_ids = _validate_response(parsed, allowed_ids)
            self.live_calls += 1
            self._write_cache(cache_key, {
                "schema_version": "llm_action_planner_v1",
                "prompt_hash": prompt_hash,
                "context": context,
                "model": self.model,
                "response_text": response_text,
                "api_latency_ms": latency,
            })
            return PlannerDecision(
                action=action,
                planner_type="llm_diagnostic",
                decision_status="live",
                reason_code=reason_code,
                evidence_ids=evidence_ids,
                prompt_hash=prompt_hash,
                response_hash=_sha256_text(response_text),
                cache_key=cache_key,
                cache_hit=False,
                api_latency_ms=latency,
                fallback_used=False,
                fallback_reason=None,
                model=self.model,
            )
        except Exception as exc:
            return self._fallback(status="api_or_validation_fallback", reason=f"{type(exc).__name__}: {exc}", prompt_hash=prompt_hash, cache_key=cache_key)

    def stats(self) -> dict[str, int]:
        return {"live_calls": int(self.live_calls), "cache_hits": int(self.cache_hits), "fallbacks": int(self.fallbacks)}
