"""Optional diagnostic controls; not part of the final CC-NSIEA method."""
