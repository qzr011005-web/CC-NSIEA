from __future__ import annotations

import torch
import torch.nn.functional as F


def supervised_contrastive_loss(
    embeddings: torch.Tensor,
    labels: torch.Tensor,
    subjects: torch.Tensor,
    temperature: float = 0.10,
) -> torch.Tensor:
    """Cross-subject supervised contrastive loss.

    Positives are same-label examples from a different subject. Anchors without
    a valid positive are excluded instead of creating an invalid loss term.
    """
    z = F.normalize(embeddings, dim=1)
    sim = (z @ z.T) / temperature
    n = len(z)
    eye = torch.eye(n, dtype=torch.bool, device=z.device)
    sim = sim.masked_fill(eye, float("-inf"))
    positive = (labels[:, None] == labels[None, :]) & (subjects[:, None] != subjects[None, :]) & ~eye
    valid = positive.any(dim=1)
    if not bool(valid.any()):
        return z.new_zeros(())
    log_denom = torch.logsumexp(sim, dim=1)
    log_prob = sim - log_denom[:, None]
    positive_log_prob = torch.where(positive, log_prob, torch.zeros_like(log_prob)).sum(dim=1)
    positive_count = positive.sum(dim=1).clamp_min(1)
    return -(positive_log_prob[valid] / positive_count[valid]).mean()


def static_hard_negative_triplet_loss(
    embeddings: torch.Tensor,
    labels: torch.Tensor,
    subjects: torch.Tensor,
    sitting_index: int,
    standing_index: int,
    margin: float = 0.20,
) -> torch.Tensor:
    """Batch-hard triplet loss for sitting versus standing across subjects."""
    z = F.normalize(embeddings, dim=1)
    dist = 1.0 - z @ z.T
    losses = []
    for anchor_idx in range(len(z)):
        label = int(labels[anchor_idx].item())
        if label not in (sitting_index, standing_index):
            continue
        other = standing_index if label == sitting_index else sitting_index
        positive_mask = (labels == label) & (subjects != subjects[anchor_idx])
        negative_mask = labels == other
        if not bool(positive_mask.any()) or not bool(negative_mask.any()):
            continue
        hardest_positive = dist[anchor_idx][positive_mask].max()
        hardest_negative = dist[anchor_idx][negative_mask].min()
        losses.append(F.relu(hardest_positive - hardest_negative + margin))
    if not losses:
        return z.new_zeros(())
    return torch.stack(losses).mean()
