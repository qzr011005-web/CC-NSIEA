from __future__ import annotations

from typing import Iterable

import numpy as np
from scipy.stats import binomtest
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score, recall_score


def classification_metrics(y_true: np.ndarray, y_pred: np.ndarray, labels: list[str], static_labels: list[str]) -> dict:
    y_true = np.asarray(y_true, dtype=object)
    y_pred = np.asarray(y_pred, dtype=object)
    out = {
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "macro_f1": float(f1_score(y_true, y_pred, labels=labels, average="macro", zero_division=0)),
        "static_macro_f1": float(f1_score(y_true, y_pred, labels=static_labels, average="macro", zero_division=0)),
        "standing_recall": float(recall_score(y_true, y_pred, labels=["standing"], average="macro", zero_division=0)),
        "sitting_recall": float(recall_score(y_true, y_pred, labels=["sitting"], average="macro", zero_division=0)),
        "confusion": confusion_matrix(y_true, y_pred, labels=labels).tolist(),
        "labels": list(labels),
    }
    return out


def bootstrap_ci_accuracy_macro_f1(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    labels: list[str],
    *,
    iterations: int,
    seed: int,
) -> dict:
    y_true = np.asarray(y_true, dtype=object)
    y_pred = np.asarray(y_pred, dtype=object)
    rng = np.random.default_rng(seed)
    acc = []
    f1 = []
    n = len(y_true)
    for _ in range(iterations):
        idx = rng.integers(0, n, size=n)
        acc.append(accuracy_score(y_true[idx], y_pred[idx]))
        f1.append(f1_score(y_true[idx], y_pred[idx], labels=labels, average="macro", zero_division=0))
    return {
        "accuracy_ci95": [float(np.quantile(acc, 0.025)), float(np.quantile(acc, 0.975))],
        "macro_f1_ci95": [float(np.quantile(f1, 0.025)), float(np.quantile(f1, 0.975))],
    }


def mcnemar_exact(y_true: Iterable[str], pred_a: Iterable[str], pred_b: Iterable[str]) -> dict:
    y_true = np.asarray(list(y_true), dtype=object)
    a = np.asarray(list(pred_a), dtype=object)
    b = np.asarray(list(pred_b), dtype=object)
    a_ok = a == y_true
    b_ok = b == y_true
    a_only = int((a_ok & ~b_ok).sum())
    b_only = int((~a_ok & b_ok).sum())
    n = a_only + b_only
    p = 1.0 if n == 0 else float(binomtest(min(a_only, b_only), n=n, p=0.5).pvalue)
    return {
        "both_correct": int((a_ok & b_ok).sum()),
        "a_correct_b_wrong": a_only,
        "a_wrong_b_correct": b_only,
        "both_wrong": int((~a_ok & ~b_ok).sum()),
        "discordant_pairs": n,
        "mcnemar_exact_p_value": p,
    }


def expected_calibration_error(probabilities: np.ndarray, y_true_idx: np.ndarray, bins: int = 15) -> float:
    probabilities = np.asarray(probabilities, dtype=np.float64)
    y_true_idx = np.asarray(y_true_idx, dtype=np.int64)
    conf = probabilities.max(axis=1)
    pred = probabilities.argmax(axis=1)
    correct = pred == y_true_idx
    ece = 0.0
    boundaries = np.linspace(0.0, 1.0, bins + 1)
    for lo, hi in zip(boundaries[:-1], boundaries[1:]):
        mask = (conf >= lo) & ((conf < hi) if hi < 1.0 else (conf <= hi))
        if not mask.any():
            continue
        ece += float(mask.mean()) * abs(float(correct[mask].mean()) - float(conf[mask].mean()))
    return float(ece)
