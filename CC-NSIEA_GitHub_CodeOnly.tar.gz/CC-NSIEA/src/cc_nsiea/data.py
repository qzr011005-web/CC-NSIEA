from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import numpy as np
import torch
from scipy.signal import butter, filtfilt
from torch.utils.data import Dataset

from .constants import UCI_NUMERIC_TO_LABEL, WISDM_TO_COMMON


@dataclass
class SequenceData:
    X: np.ndarray  # [N, C, T]
    y: np.ndarray  # [N] labels as strings
    groups: np.ndarray  # [N] subject/user integer ids
    indices: np.ndarray  # [N] row ids local to source corpus
    source: str


def _read_matrix(path: Path) -> np.ndarray:
    return np.loadtxt(path, dtype=np.float32)


def _resolve_uci_root(data_dir: str | Path) -> Path:
    data_dir = Path(data_dir)
    direct = data_dir / "UCI HAR Dataset"
    if direct.exists():
        return direct
    if (data_dir / "train").exists() and (data_dir / "test").exists():
        return data_dir
    raise FileNotFoundError(
        f"Cannot find UCI HAR Dataset under {data_dir}. Expected "
        f"{direct} or a directory containing train/ and test/."
    )


def load_uci_train_common_acceleration(data_dir: str | Path) -> SequenceData:
    """Load only the official UCI HAR training split as [total, body, gravity].

    The UCI official test split is deliberately not touched by this function.
    """
    root = _resolve_uci_root(data_dir)
    signal_dir = root / "train" / "Inertial Signals"
    y_num = np.loadtxt(root / "train" / "y_train.txt", dtype=np.int64)
    subjects = np.loadtxt(root / "train" / "subject_train.txt", dtype=np.int64)

    total = []
    body = []
    for axis in ("x", "y", "z"):
        total.append(_read_matrix(signal_dir / f"total_acc_{axis}_train.txt"))
        body.append(_read_matrix(signal_dir / f"body_acc_{axis}_train.txt"))

    total_arr = np.stack(total, axis=1)
    body_arr = np.stack(body, axis=1)
    gravity_arr = total_arr - body_arr
    X = np.concatenate([total_arr, body_arr, gravity_arr], axis=1).astype(np.float32)

    if X.shape[0] != len(y_num) or len(y_num) != len(subjects):
        raise RuntimeError("UCI train signal, label, and subject row counts disagree.")
    if X.shape[1:] != (9, 128):
        raise RuntimeError(f"Unexpected UCI common representation shape: {X.shape}")

    labels = np.asarray([UCI_NUMERIC_TO_LABEL[int(v)] for v in y_num], dtype=object)
    return SequenceData(
        X=X,
        y=labels,
        groups=subjects.astype(np.int64),
        indices=np.arange(len(labels), dtype=np.int64),
        source="uci_har_official_train",
    )


def parse_wisdm_line(line: str) -> tuple[int, str, float, float, float, float] | None:
    """Parse WISDM v1.1 raw records: user,activity,timestamp,x,y,z;"""
    raw = line.strip()
    if not raw:
        return None
    raw = raw.rstrip(";")
    parts = [p.strip() for p in raw.split(",")]
    if len(parts) != 6:
        return None
    try:
        user = int(float(parts[0]))
        activity = parts[1].lower()
        ts, x, y, z = (float(parts[i]) for i in range(2, 6))
    except ValueError:
        return None
    if activity not in WISDM_TO_COMMON:
        return None
    return user, WISDM_TO_COMMON[activity], ts, x, y, z


def read_wisdm_raw(raw_path: str | Path) -> np.ndarray:
    rows: list[tuple[int, str, float, float, float, float]] = []
    with Path(raw_path).open("r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            parsed = parse_wisdm_line(line)
            if parsed is not None:
                rows.append(parsed)
    if not rows:
        raise RuntimeError("No supported WISDM records were parsed.")
    dtype = np.dtype([
        ("user", np.int64),
        ("activity", "U32"),
        ("timestamp", np.float64),
        ("x", np.float32),
        ("y", np.float32),
        ("z", np.float32),
    ])
    arr = np.asarray(rows, dtype=dtype)
    order = np.lexsort((arr["timestamp"], arr["user"]))
    return arr[order]


def infer_timestamp_scale(timestamps: np.ndarray) -> float:
    """Map raw timestamps to seconds by matching the median interval to ~20 Hz.

    WISDM v1.1 timestamps have historically appeared in high-resolution units.
    The inference avoids hard-coding nanoseconds while remaining deterministic.
    """
    t = np.asarray(timestamps, dtype=np.float64)
    diffs = np.diff(np.unique(t))
    diffs = diffs[diffs > 0]
    if len(diffs) == 0:
        return 1.0
    median = float(np.median(diffs))
    candidates = (1.0, 1e3, 1e6, 1e9)
    target = 1.0 / 20.0
    return min(candidates, key=lambda div: abs(np.log(max(median / div, 1e-12) / target)))


def lowpass_gravity(signal: np.ndarray, fs: float, cutoff_hz: float) -> np.ndarray:
    """Low-pass gravity estimate with a deterministic short-sequence fallback."""
    if signal.ndim != 2 or signal.shape[1] != 3:
        raise ValueError("signal must have shape [T, 3]")
    nyq = fs / 2.0
    if cutoff_hz <= 0 or cutoff_hz >= nyq:
        raise ValueError("cutoff_hz must lie in (0, fs/2)")
    b, a = butter(3, cutoff_hz / nyq, btype="low")
    padlen = 3 * max(len(a), len(b))
    if len(signal) <= padlen:
        width = max(3, int(round(fs / max(cutoff_hz, 1e-6))))
        width = min(width, len(signal))
        kernel = np.ones(width, dtype=np.float32) / width
        return np.stack([np.convolve(signal[:, j], kernel, mode="same") for j in range(3)], axis=1)
    return filtfilt(b, a, signal, axis=0).astype(np.float32)


def _resample_segment(times_s: np.ndarray, xyz: np.ndarray, target_hz: float) -> tuple[np.ndarray, np.ndarray]:
    if len(times_s) < 2:
        return np.empty(0, dtype=np.float64), np.empty((0, 3), dtype=np.float32)
    start, end = float(times_s[0]), float(times_s[-1])
    step = 1.0 / target_hz
    target_t = np.arange(start, end + step * 0.25, step, dtype=np.float64)
    if len(target_t) < 2:
        return np.empty(0, dtype=np.float64), np.empty((0, 3), dtype=np.float32)
    target_xyz = np.stack(
        [np.interp(target_t, times_s, xyz[:, j]) for j in range(3)], axis=1
    ).astype(np.float32)
    return target_t, target_xyz


def build_wisdm_windows(
    raw: np.ndarray,
    *,
    target_hz: float,
    window_length: int,
    stride: int,
    gravity_cutoff_hz: float,
    max_gap_factor: float,
) -> SequenceData:
    """Create deterministic 9-channel windows from WISDM raw accelerometer records."""
    scale = infer_timestamp_scale(raw["timestamp"])
    times = raw["timestamp"].astype(np.float64) / scale

    windows: list[np.ndarray] = []
    labels: list[str] = []
    users: list[int] = []
    row_id = 0
    indices: list[int] = []

    # Segment whenever user, label, or timing continuity changes.
    start = 0
    n = len(raw)
    for end in range(1, n + 1):
        boundary = end == n
        if not boundary:
            same_user = raw["user"][end] == raw["user"][end - 1]
            same_activity = raw["activity"][end] == raw["activity"][end - 1]
            gap = times[end] - times[end - 1]
            local_nominal = 1.0 / 20.0
            boundary = (not same_user) or (not same_activity) or gap <= 0 or gap > max_gap_factor * local_nominal
        if not boundary:
            continue

        seg_times = times[start:end]
        seg_xyz = np.stack([raw["x"][start:end], raw["y"][start:end], raw["z"][start:end]], axis=1)
        _, resampled = _resample_segment(seg_times, seg_xyz, target_hz)
        if len(resampled) >= window_length:
            gravity = lowpass_gravity(resampled, target_hz, gravity_cutoff_hz)
            body = resampled - gravity
            for offset in range(0, len(resampled) - window_length + 1, stride):
                total_w = resampled[offset: offset + window_length]
                body_w = body[offset: offset + window_length]
                gravity_w = gravity[offset: offset + window_length]
                feature = np.concatenate([total_w.T, body_w.T, gravity_w.T], axis=0).astype(np.float32)
                windows.append(feature)
                labels.append(str(raw["activity"][start]))
                users.append(int(raw["user"][start]))
                indices.append(row_id)
                row_id += 1
        start = end

    if not windows:
        raise RuntimeError("No WISDM windows were generated. Inspect raw parsing and timestamp continuity.")
    return SequenceData(
        X=np.stack(windows).astype(np.float32),
        y=np.asarray(labels, dtype=object),
        groups=np.asarray(users, dtype=np.int64),
        indices=np.asarray(indices, dtype=np.int64),
        source="wisdm_activity_prediction_raw",
    )


def save_sequence_npz(path: str | Path, data: SequenceData, metadata: dict) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(
        path,
        X=data.X.astype(np.float32),
        y=data.y.astype("U32"),
        groups=data.groups.astype(np.int64),
        indices=data.indices.astype(np.int64),
        source=np.asarray([data.source], dtype="U64"),
        metadata=np.asarray([str(metadata)], dtype="U4096"),
    )


def load_sequence_npz(path: str | Path) -> SequenceData:
    obj = np.load(Path(path), allow_pickle=False)
    return SequenceData(
        X=obj["X"].astype(np.float32),
        y=obj["y"].astype(object),
        groups=obj["groups"].astype(np.int64),
        indices=obj["indices"].astype(np.int64),
        source=str(obj["source"][0]),
    )


class SequenceDataset(Dataset):
    def __init__(self, X: np.ndarray, y_idx: np.ndarray, groups: np.ndarray, augment_jitter_std: float = 0.0):
        self.X = np.asarray(X, dtype=np.float32)
        self.y = np.asarray(y_idx, dtype=np.int64)
        self.groups = np.asarray(groups, dtype=np.int64)
        self.augment_jitter_std = float(augment_jitter_std)

    def __len__(self) -> int:
        return len(self.X)

    def __getitem__(self, index: int):
        x = self.X[index].copy()
        if self.augment_jitter_std > 0:
            x += np.random.normal(0.0, self.augment_jitter_std, size=x.shape).astype(np.float32)
        return (
            torch.from_numpy(x),
            torch.tensor(self.y[index], dtype=torch.long),
            torch.tensor(self.groups[index], dtype=torch.long),
            torch.tensor(index, dtype=torch.long),
        )


def label_to_index(labels: Iterable[str], ordered_labels: Iterable[str]) -> np.ndarray:
    mapping = {name: idx for idx, name in enumerate(ordered_labels)}
    return np.asarray([mapping[str(y)] for y in labels], dtype=np.int64)
