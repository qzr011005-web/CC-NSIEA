from __future__ import annotations

from itertools import combinations
from typing import Any

import numpy as np
from sklearn.model_selection import GroupKFold

from .utils import jsonable


def _label_distribution_score(y: np.ndarray, selected: np.ndarray, labels: list[str]) -> float:
    values = []
    for label in labels:
        values.append(float(np.mean(y[selected] == label)))
    return float(np.std(values))


def build_nested_subject_protocol(
    y: np.ndarray,
    subjects: np.ndarray,
    labels: list[str],
    *,
    outer_folds: int,
    inner_val_ratio: float,
    seed: int,
    trials: int,
) -> dict[str, Any]:
    y = np.asarray(y, dtype=object)
    subjects = np.asarray(subjects, dtype=np.int64)
    unique_subjects = np.unique(subjects)
    if len(unique_subjects) < outer_folds:
        raise ValueError("Not enough unique subjects for outer folds.")

    outer = GroupKFold(n_splits=outer_folds)
    folds = []
    for fold_id, (outer_train_idx, outer_test_idx) in enumerate(outer.split(np.zeros(len(y)), y, subjects)):
        outer_train_subjects = np.unique(subjects[outer_train_idx])
        n_val = max(1, int(round(len(outer_train_subjects) * inner_val_ratio)))
        n_val = min(n_val, len(outer_train_subjects) - 1)
        rng = np.random.default_rng(seed + fold_id * 101)
        best = None

        # Candidate generation is deterministic with the seed. Each candidate must preserve all labels.
        for _ in range(trials):
            candidate_val_subjects = np.sort(rng.choice(outer_train_subjects, size=n_val, replace=False))
            val_mask = np.isin(subjects[outer_train_idx], candidate_val_subjects)
            val_idx = outer_train_idx[val_mask]
            train_idx = outer_train_idx[~val_mask]
            if len(train_idx) == 0 or len(val_idx) == 0:
                continue
            if set(y[train_idx]) != set(labels) or set(y[val_idx]) != set(labels):
                continue
            score = _label_distribution_score(y, val_idx, labels)
            tie = tuple(candidate_val_subjects.tolist())
            candidate = (score, tie, candidate_val_subjects, train_idx, val_idx)
            if best is None or candidate[:2] < best[:2]:
                best = candidate

        if best is None:
            # Exhaustive fallback for small subject counts.
            for comb in combinations(outer_train_subjects.tolist(), n_val):
                candidate_val_subjects = np.asarray(comb, dtype=np.int64)
                val_mask = np.isin(subjects[outer_train_idx], candidate_val_subjects)
                val_idx = outer_train_idx[val_mask]
                train_idx = outer_train_idx[~val_mask]
                if set(y[train_idx]) != set(labels) or set(y[val_idx]) != set(labels):
                    continue
                score = _label_distribution_score(y, val_idx, labels)
                candidate = (score, tuple(comb), candidate_val_subjects, train_idx, val_idx)
                if best is None or candidate[:2] < best[:2]:
                    best = candidate
        if best is None:
            raise RuntimeError(f"Cannot construct valid inner split for outer fold {fold_id}.")

        _, _, val_subjects, inner_train_idx, inner_val_idx = best
        test_subjects = np.unique(subjects[outer_test_idx])
        sets = [set(subjects[inner_train_idx]), set(subjects[inner_val_idx]), set(test_subjects)]
        if sets[0] & sets[1] or sets[0] & sets[2] or sets[1] & sets[2]:
            raise AssertionError("Subject overlap in nested protocol.")

        folds.append({
            "fold": fold_id,
            "inner_train_indices": inner_train_idx.tolist(),
            "inner_val_indices": inner_val_idx.tolist(),
            "outer_train_indices": outer_train_idx.tolist(),
            "outer_test_indices": outer_test_idx.tolist(),
            "inner_train_subjects": sorted(set(subjects[inner_train_idx].tolist())),
            "inner_val_subjects": sorted(set(subjects[inner_val_idx].tolist())),
            "outer_test_subjects": sorted(set(test_subjects.tolist())),
        })

    protocol = {
        "protocol": "nested_subject_disjoint_official_uci_train_only",
        "official_test_labels_used": False,
        "n_samples": int(len(y)),
        "n_subjects": int(len(unique_subjects)),
        "subjects": sorted(unique_subjects.tolist()),
        "labels": list(labels),
        "outer_folds": int(outer_folds),
        "seed": int(seed),
        "folds": folds,
    }
    return jsonable(protocol)


def build_wisdm_user_protocol(
    y: np.ndarray,
    users: np.ndarray,
    labels: list[str],
    *,
    train_users: int,
    val_users: int,
    test_users: int,
    seed: int,
    trials: int,
) -> dict[str, Any]:
    y = np.asarray(y, dtype=object)
    users = np.asarray(users, dtype=np.int64)
    unique_users = np.sort(np.unique(users))
    if train_users + val_users + test_users != len(unique_users):
        raise ValueError(
            "Requested train/val/test user counts must equal the number of processed WISDM users. "
            f"Requested {train_users + val_users + test_users}, found {len(unique_users)}."
        )
    rng = np.random.default_rng(seed)
    best = None
    for _ in range(trials):
        perm = rng.permutation(unique_users)
        train = np.sort(perm[:train_users])
        val = np.sort(perm[train_users:train_users + val_users])
        test = np.sort(perm[train_users + val_users:])
        all_have_labels = True
        score = 0.0
        for group in (train, val, test):
            mask = np.isin(users, group)
            present = set(y[mask])
            if present != set(labels):
                all_have_labels = False
                break
            # Balance score is used only to pre-specify a stratified user split;
            # no model or hyperparameter is inspected here.
            score += _label_distribution_score(y, np.flatnonzero(mask), labels)
        if not all_have_labels:
            continue
        candidate = (score, tuple(train.tolist()), tuple(val.tolist()), tuple(test.tolist()))
        if best is None or candidate < best:
            best = candidate
    if best is None:
        raise RuntimeError("Could not find a user-disjoint WISDM split covering every class.")
    _, train, val, test = best
    protocol = {
        "protocol": "wisdm_user_disjoint_stratified_predeclared",
        "official_test_labels_used": False,
        "labels": list(labels),
        "seed": int(seed),
        "train_users": list(train),
        "val_users": list(val),
        "test_users": list(test),
        "split_selection_note": "Class coverage/balance is used only to pre-specify a user-level split before model training; test users are not used for model selection.",
    }
    return jsonable(protocol)


def validate_protocol_no_overlap(protocol: dict[str, Any]) -> None:
    if "folds" in protocol:
        for fold in protocol["folds"]:
            groups = [
                set(fold["inner_train_subjects"]),
                set(fold["inner_val_subjects"]),
                set(fold["outer_test_subjects"]),
            ]
            if groups[0] & groups[1] or groups[0] & groups[2] or groups[1] & groups[2]:
                raise AssertionError(f"Subject overlap in fold {fold['fold']}")
    else:
        groups = [set(protocol["train_users"]), set(protocol["val_users"]), set(protocol["test_users"])]
        if groups[0] & groups[1] or groups[0] & groups[2] or groups[1] & groups[2]:
            raise AssertionError("User overlap in WISDM protocol")


def build_four_way_subject_audit_protocol(
    y: np.ndarray,
    subjects: np.ndarray,
    labels: list[str],
    *,
    outer_folds: int,
    model_selection_subjects: int,
    audit_calibration_subjects: int,
    seed: int,
    trials: int,
) -> dict[str, Any]:
    """Build a nested subject-disjoint protocol with a separate audit-calibration set.

    Each outer fold is partitioned into four subject-disjoint roles:
    model_train -> train the neural perception model;
    model_selection -> select training epoch;
    audit_calibration -> select only the evidence-stop threshold tau;
    outer_test -> final untouched evaluation.

    The split is selected solely from labels/subjects before any model is trained.
    """
    y = np.asarray(y, dtype=object)
    subjects = np.asarray(subjects, dtype=np.int64)
    unique_subjects = np.unique(subjects)
    if len(unique_subjects) < outer_folds:
        raise ValueError("Not enough unique subjects for outer folds.")

    outer = GroupKFold(n_splits=outer_folds)
    folds: list[dict[str, Any]] = []
    for fold_id, (outer_train_idx, outer_test_idx) in enumerate(outer.split(np.zeros(len(y)), y, subjects)):
        outer_train_subjects = np.sort(np.unique(subjects[outer_train_idx]))
        n_needed = int(model_selection_subjects) + int(audit_calibration_subjects) + 1
        if len(outer_train_subjects) < n_needed:
            raise RuntimeError(
                f"Fold {fold_id} has only {len(outer_train_subjects)} outer-train subjects, "
                f"but needs at least {n_needed} for train/select/audit roles."
            )

        rng = np.random.default_rng(seed + fold_id * 10_007)
        best = None
        for _ in range(int(trials)):
            perm = rng.permutation(outer_train_subjects)
            sel_subjects = np.sort(perm[: int(model_selection_subjects)])
            cal_subjects = np.sort(perm[int(model_selection_subjects): int(model_selection_subjects) + int(audit_calibration_subjects)])
            train_subjects = np.sort(perm[int(model_selection_subjects) + int(audit_calibration_subjects):])
            if len(train_subjects) == 0:
                continue
            idx_train = outer_train_idx[np.isin(subjects[outer_train_idx], train_subjects)]
            idx_sel = outer_train_idx[np.isin(subjects[outer_train_idx], sel_subjects)]
            idx_cal = outer_train_idx[np.isin(subjects[outer_train_idx], cal_subjects)]
            if min(len(idx_train), len(idx_sel), len(idx_cal)) == 0:
                continue
            if set(y[idx_train]) != set(labels) or set(y[idx_sel]) != set(labels) or set(y[idx_cal]) != set(labels):
                continue
            # Select an a-priori balanced subject partition without inspecting model scores.
            score = (
                _label_distribution_score(y, idx_train, labels)
                + _label_distribution_score(y, idx_sel, labels)
                + _label_distribution_score(y, idx_cal, labels)
            )
            tie = (tuple(train_subjects.tolist()), tuple(sel_subjects.tolist()), tuple(cal_subjects.tolist()))
            candidate = (float(score), tie, train_subjects, sel_subjects, cal_subjects, idx_train, idx_sel, idx_cal)
            if best is None or candidate[:2] < best[:2]:
                best = candidate

        if best is None:
            # Exhaustive fallback is feasible because UCI HAR has a small subject count.
            for sel_tuple in combinations(outer_train_subjects.tolist(), int(model_selection_subjects)):
                remaining_after_sel = np.asarray([s for s in outer_train_subjects if s not in set(sel_tuple)], dtype=np.int64)
                for cal_tuple in combinations(remaining_after_sel.tolist(), int(audit_calibration_subjects)):
                    sel_subjects = np.asarray(sel_tuple, dtype=np.int64)
                    cal_subjects = np.asarray(cal_tuple, dtype=np.int64)
                    train_subjects = np.asarray(
                        [s for s in outer_train_subjects if s not in set(sel_tuple) and s not in set(cal_tuple)],
                        dtype=np.int64,
                    )
                    idx_train = outer_train_idx[np.isin(subjects[outer_train_idx], train_subjects)]
                    idx_sel = outer_train_idx[np.isin(subjects[outer_train_idx], sel_subjects)]
                    idx_cal = outer_train_idx[np.isin(subjects[outer_train_idx], cal_subjects)]
                    if min(len(idx_train), len(idx_sel), len(idx_cal)) == 0:
                        continue
                    if set(y[idx_train]) != set(labels) or set(y[idx_sel]) != set(labels) or set(y[idx_cal]) != set(labels):
                        continue
                    score = (
                        _label_distribution_score(y, idx_train, labels)
                        + _label_distribution_score(y, idx_sel, labels)
                        + _label_distribution_score(y, idx_cal, labels)
                    )
                    tie = (tuple(train_subjects.tolist()), tuple(sel_subjects.tolist()), tuple(cal_subjects.tolist()))
                    candidate = (float(score), tie, train_subjects, sel_subjects, cal_subjects, idx_train, idx_sel, idx_cal)
                    if best is None or candidate[:2] < best[:2]:
                        best = candidate

        if best is None:
            raise RuntimeError(f"Cannot construct a valid four-way split for outer fold {fold_id}.")

        _, _, train_subjects, sel_subjects, cal_subjects, idx_train, idx_sel, idx_cal = best
        test_subjects = np.sort(np.unique(subjects[outer_test_idx]))
        role_sets = [set(train_subjects.tolist()), set(sel_subjects.tolist()), set(cal_subjects.tolist()), set(test_subjects.tolist())]
        for i in range(len(role_sets)):
            for j in range(i + 1, len(role_sets)):
                if role_sets[i] & role_sets[j]:
                    raise AssertionError(f"Subject overlap in fold {fold_id}: roles {i} and {j}.")

        folds.append({
            "fold": int(fold_id),
            "model_train_indices": np.asarray(idx_train, dtype=np.int64).tolist(),
            "model_selection_indices": np.asarray(idx_sel, dtype=np.int64).tolist(),
            "audit_calibration_indices": np.asarray(idx_cal, dtype=np.int64).tolist(),
            "outer_test_indices": np.asarray(outer_test_idx, dtype=np.int64).tolist(),
            "model_train_subjects": sorted(train_subjects.astype(int).tolist()),
            "model_selection_subjects": sorted(sel_subjects.astype(int).tolist()),
            "audit_calibration_subjects": sorted(cal_subjects.astype(int).tolist()),
            "outer_test_subjects": sorted(test_subjects.astype(int).tolist()),
        })

    protocol = {
        "protocol": "four_way_nested_subject_disjoint_evidence_audit_official_uci_train_only",
        "official_test_labels_used": False,
        "n_samples": int(len(y)),
        "n_subjects": int(len(unique_subjects)),
        "subjects": sorted(unique_subjects.astype(int).tolist()),
        "labels": list(labels),
        "outer_folds": int(outer_folds),
        "model_selection_subjects_per_fold": int(model_selection_subjects),
        "audit_calibration_subjects_per_fold": int(audit_calibration_subjects),
        "seed": int(seed),
        "folds": folds,
    }
    validate_four_way_audit_protocol(protocol)
    return jsonable(protocol)


def validate_four_way_audit_protocol(protocol: dict[str, Any]) -> None:
    if protocol.get("official_test_labels_used") is not False:
        raise AssertionError("Protocol must set official_test_labels_used=false.")
    required = {
        "model_train_subjects",
        "model_selection_subjects",
        "audit_calibration_subjects",
        "outer_test_subjects",
        "model_train_indices",
        "model_selection_indices",
        "audit_calibration_indices",
        "outer_test_indices",
    }
    seen_test: list[int] = []
    for fold in protocol.get("folds", []):
        missing = required - set(fold)
        if missing:
            raise AssertionError(f"Missing fields in fold {fold.get('fold')}: {sorted(missing)}")
        roles = [
            set(fold["model_train_subjects"]),
            set(fold["model_selection_subjects"]),
            set(fold["audit_calibration_subjects"]),
            set(fold["outer_test_subjects"]),
        ]
        for i in range(4):
            for j in range(i + 1, 4):
                if roles[i] & roles[j]:
                    raise AssertionError(f"Subject overlap in fold {fold['fold']}: roles {i}/{j}")
        idx_roles = [
            set(fold["model_train_indices"]),
            set(fold["model_selection_indices"]),
            set(fold["audit_calibration_indices"]),
            set(fold["outer_test_indices"]),
        ]
        for i in range(4):
            for j in range(i + 1, 4):
                if idx_roles[i] & idx_roles[j]:
                    raise AssertionError(f"Index overlap in fold {fold['fold']}: roles {i}/{j}")
        seen_test.extend(int(v) for v in fold["outer_test_indices"])
    if len(seen_test) != len(set(seen_test)):
        raise AssertionError("Outer-test OOF indices are duplicated across folds.")
    if protocol.get("n_samples") is not None and len(seen_test) != int(protocol["n_samples"]):
        raise AssertionError("Outer-test OOF indices do not cover every source row exactly once.")
