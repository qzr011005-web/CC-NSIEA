from __future__ import annotations

import torch
from torch import nn
import torch.nn.functional as F


class ResidualTemporalBlock(nn.Module):
    def __init__(self, channels: int, dilation: int, dropout: float):
        super().__init__()
        kernel = 3
        padding = dilation
        self.conv1 = nn.Conv1d(channels, channels, kernel, padding=padding, dilation=dilation, bias=False)
        self.norm1 = nn.GroupNorm(num_groups=min(8, channels), num_channels=channels)
        self.conv2 = nn.Conv1d(channels, channels, kernel, padding=padding, dilation=dilation, bias=False)
        self.norm2 = nn.GroupNorm(num_groups=min(8, channels), num_channels=channels)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        residual = x
        x = self.conv1(x)
        x = F.gelu(self.norm1(x))
        x = self.dropout(x)
        x = self.conv2(x)
        x = self.norm2(x)
        return F.gelu(x + residual)


class AttentionPool(nn.Module):
    def __init__(self, channels: int):
        super().__init__()
        self.score = nn.Conv1d(channels, 1, kernel_size=1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        weights = torch.softmax(self.score(x), dim=-1)
        return torch.sum(x * weights, dim=-1)


class TemporalResNetClassifier(nn.Module):
    def __init__(
        self,
        input_channels: int,
        num_classes: int,
        channels: int = 64,
        embedding_dim: int = 128,
        dropout: float = 0.1,
        dilations: tuple[int, ...] = (1, 2, 4, 8),
    ):
        super().__init__()
        self.stem = nn.Sequential(
            nn.Conv1d(input_channels, channels, kernel_size=5, padding=2, bias=False),
            nn.GroupNorm(num_groups=min(8, channels), num_channels=channels),
            nn.GELU(),
        )
        self.blocks = nn.Sequential(*[
            ResidualTemporalBlock(channels, int(d), dropout) for d in dilations
        ])
        self.pool = AttentionPool(channels)
        self.projector = nn.Sequential(
            nn.Linear(channels, embedding_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(embedding_dim, embedding_dim),
        )
        self.classifier = nn.Linear(embedding_dim, num_classes)

    def forward(self, x: torch.Tensor) -> dict[str, torch.Tensor]:
        h = self.blocks(self.stem(x))
        pooled = self.pool(h)
        embedding_raw = self.projector(pooled)
        embedding = F.normalize(embedding_raw, p=2, dim=1)
        logits = self.classifier(embedding_raw)
        return {"logits": logits, "embedding": embedding}
