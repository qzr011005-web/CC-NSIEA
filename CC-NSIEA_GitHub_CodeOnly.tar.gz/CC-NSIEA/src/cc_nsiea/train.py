from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np
import torch
import torch.nn.functional as F
from torch.optim import AdamW
from torch.utils.data import DataLoader, WeightedRandomSampler
from tqdm.auto import tqdm

from .data import SequenceDataset
from .losses import supervised_contrastive_loss, static_hard_negative_triplet_loss
from .metrics import classification_metrics
from .model import TemporalResNetClassifier
from .utils import resolve_device, set_seed


@dataclass
class Standardizer:
    mean: np.ndarray
    std: np.ndarray

    @classmethod
    def fit(cls, X: np.ndarray) -> "Standardizer":
        mean = X.mean(axis=(0, 2), keepdims=True).astype(np.float32)
        std = X.std(axis=(0, 2), keepdims=True).astype(np.float32)
        std = np.maximum(std, 1e-6)
        return cls(mean=mean, std=std)

    def transform(self, X: np.ndarray) -> np.ndarray:
        return ((X - self.mean) / self.std).astype(np.float32)

    def state(self) -> dict[str, np.ndarray]:
        return {"mean": self.mean, "std": self.std}


def build_model(cfg: dict[str, Any], num_classes: int) -> TemporalResNetClassifier:
    m = cfg["model"]
    return TemporalResNetClassifier(
        input_channels=int(cfg["data"]["input_channels"]),
        num_classes=int(num_classes),
        channels=int(m["channels"]),
        embedding_dim=int(m["embedding_dim"]),
        dropout=float(m["dropout"]),
        dilations=tuple(int(v) for v in m["dilations"]),
    )


def variant_config(cfg: dict[str, Any], variant: str) -> dict[str, Any]:
    if variant not in {"e0", "e1", "e2", "e3", "e4"}:
        raise ValueError(f"Unknown variant: {variant}")
    out = {
        "variant": variant,
        "subject_balanced": variant in {"e1", "e2", "e3", "e4"},
        "supcon_weight": float(cfg["loss"]["supcon_weight"]) if variant in {"e2", "e3", "e4"} else 0.0,
        "static_hn_weight": float(cfg["loss"]["static_hn_weight"]) if variant in {"e3", "e4"} else 0.0,
        "temperature_calibration": variant == "e4",
    }
    return out


def _subject_balanced_sampler(subjects: np.ndarray) -> WeightedRandomSampler:
    subjects = np.asarray(subjects)
    values, counts = np.unique(subjects, return_counts=True)
    inv = {int(v): 1.0 / float(c) for v, c in zip(values, counts)}
    weights = np.asarray([inv[int(s)] for s in subjects], dtype=np.float64)
    return WeightedRandomSampler(torch.from_numpy(weights), num_samples=len(weights), replacement=True)


def _make_loader(
    X: np.ndarray,
    y: np.ndarray,
    groups: np.ndarray,
    *,
    batch_size: int,
    jitter: float,
    subject_balanced: bool,
    shuffle: bool,
) -> DataLoader:
    ds = SequenceDataset(X, y, groups, augment_jitter_std=jitter)
    sampler = _subject_balanced_sampler(groups) if subject_balanced else None
    return DataLoader(
        ds,
        batch_size=batch_size,
        shuffle=bool(shuffle and sampler is None),
        sampler=sampler,
        num_workers=0,
        pin_memory=torch.cuda.is_available(),
        drop_last=False,
    )


def _epoch_train(
    model: torch.nn.Module,
    loader: DataLoader,
    optimizer: torch.optim.Optimizer,
    *,
    device: torch.device,
    loss_cfg: dict[str, Any],
    sitting_idx: int,
    standing_idx: int,
    grad_clip_norm: float,
) -> dict[str, float]:
    model.train()
    totals = {"loss": 0.0, "ce": 0.0, "supcon": 0.0, "static_hn": 0.0, "n": 0}
    for x, y, subjects, _ in loader:
        x, y, subjects = x.to(device), y.to(device), subjects.to(device)
        out = model(x)
        ce = F.cross_entropy(out["logits"], y)
        sup_weight = float(loss_cfg["supcon_weight"])
        hard_weight = float(loss_cfg["static_hn_weight"])
        sup = (
            supervised_contrastive_loss(out["embedding"], y, subjects, float(loss_cfg["supcon_temperature"]))
            if sup_weight > 0.0 else torch.zeros((), device=device)
        )
        hard = (
            static_hard_negative_triplet_loss(
                out["embedding"], y, subjects, sitting_idx, standing_idx,
                float(loss_cfg["static_hn_margin"]),
            ) if hard_weight > 0.0 else torch.zeros((), device=device)
        )
        loss = ce + sup_weight * sup + hard_weight * hard
        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), grad_clip_norm)
        optimizer.step()
        bs = len(x)
        totals["loss"] += float(loss.detach().cpu()) * bs
        totals["ce"] += float(ce.detach().cpu()) * bs
        totals["supcon"] += float(sup.detach().cpu()) * bs
        totals["static_hn"] += float(hard.detach().cpu()) * bs
        totals["n"] += bs
    return {k: totals[k] / max(totals["n"], 1) for k in ("loss", "ce", "supcon", "static_hn")}


def predict(
    model: torch.nn.Module,
    X: np.ndarray,
    y: np.ndarray,
    groups: np.ndarray,
    labels: list[str],
    *,
    batch_size: int,
    device: torch.device,
    temperature: float = 1.0,
) -> dict[str, np.ndarray]:
    loader = _make_loader(X, y, groups, batch_size=batch_size, jitter=0.0, subject_balanced=False, shuffle=False)
    model.eval()
    all_logits, all_embed, all_true, all_group, all_local = [], [], [], [], []
    with torch.no_grad():
        for x, target, subject, local_idx in loader:
            out = model(x.to(device))
            all_logits.append(out["logits"].cpu().numpy())
            all_embed.append(out["embedding"].cpu().numpy())
            all_true.append(target.numpy())
            all_group.append(subject.numpy())
            all_local.append(local_idx.numpy())
    logits = np.concatenate(all_logits, axis=0)
    probs = torch.softmax(torch.from_numpy(logits) / float(temperature), dim=1).numpy()
    pred_idx = probs.argmax(axis=1)
    return {
        "logits": logits,
        "probabilities": probs,
        "embeddings": np.concatenate(all_embed, axis=0),
        "y_idx": np.concatenate(all_true, axis=0),
        "pred_idx": pred_idx,
        "y_label": np.asarray([labels[int(i)] for i in np.concatenate(all_true)], dtype=object),
        "pred_label": np.asarray([labels[int(i)] for i in pred_idx], dtype=object),
        "groups": np.concatenate(all_group),
        "local_index": np.concatenate(all_local),
    }


def fit_temperature(logits: np.ndarray, y_idx: np.ndarray, max_iter: int = 50) -> float:
    logits_t = torch.tensor(logits, dtype=torch.float32)
    target_t = torch.tensor(y_idx, dtype=torch.long)
    log_temp = torch.nn.Parameter(torch.zeros(()))
    optimizer = torch.optim.LBFGS([log_temp], lr=0.1, max_iter=max_iter)

    def closure():
        optimizer.zero_grad()
        temp = torch.exp(log_temp).clamp(0.05, 20.0)
        loss = F.cross_entropy(logits_t / temp, target_t)
        loss.backward()
        return loss

    optimizer.step(closure)
    return float(torch.exp(log_temp).detach().clamp(0.05, 20.0).cpu())


def select_epoch(
    X_train: np.ndarray,
    y_train: np.ndarray,
    g_train: np.ndarray,
    X_val: np.ndarray,
    y_val: np.ndarray,
    g_val: np.ndarray,
    labels: list[str],
    cfg: dict[str, Any],
    variant: str,
    seed: int,
) -> dict[str, Any]:
    set_seed(seed)
    device = resolve_device(str(cfg["training"]["device"]))
    vcfg = variant_config(cfg, variant)
    model = build_model(cfg, len(labels)).to(device)
    optimizer = AdamW(model.parameters(), lr=float(cfg["training"]["learning_rate"]), weight_decay=float(cfg["training"]["weight_decay"]))
    train_loader = _make_loader(
        X_train, y_train, g_train,
        batch_size=int(cfg["training"]["batch_size"]),
        jitter=float(cfg["training"]["augmentation_jitter_std"]),
        subject_balanced=vcfg["subject_balanced"], shuffle=True,
    )
    sitting_idx, standing_idx = labels.index("sitting"), labels.index("standing")
    loss_cfg = dict(cfg["loss"])
    loss_cfg["supcon_weight"] = vcfg["supcon_weight"]
    loss_cfg["static_hn_weight"] = vcfg["static_hn_weight"]
    static_labels = [x for x in cfg["evaluation"]["static_labels"] if x in labels]
    best = None
    wait = 0
    history = []
    progress = tqdm(range(1, int(cfg["training"]["epochs"]) + 1), desc=f"{variant} selection", unit="epoch", leave=False)
    for epoch in progress:
        train_stats = _epoch_train(
            model, train_loader, optimizer, device=device, loss_cfg=loss_cfg,
            sitting_idx=sitting_idx, standing_idx=standing_idx,
            grad_clip_norm=float(cfg["training"]["grad_clip_norm"]),
        )
        pred = predict(model, X_val, y_val, g_val, labels, batch_size=int(cfg["training"]["eval_batch_size"]), device=device)
        metric = classification_metrics(pred["y_label"], pred["pred_label"], labels, static_labels)
        record = {"epoch": epoch, **train_stats, **metric}
        history.append(record)
        key = (metric["macro_f1"], metric["static_macro_f1"], metric["accuracy"])
        if best is None or key > best["key"]:
            best = {"key": key, "epoch": epoch, "state": {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}, "metrics": metric}
            wait = 0
        else:
            wait += 1
        progress.set_postfix(
            loss=f"{train_stats['loss']:.4f}",
            val_f1=f"{metric['macro_f1']:.4f}",
            static_f1=f"{metric['static_macro_f1']:.4f}",
            best_epoch=int(best["epoch"]),
            wait=wait,
        )
        if wait >= int(cfg["training"]["early_stopping_patience"]):
            progress.set_postfix(status="early_stop", best_epoch=int(best["epoch"]), wait=wait)
            break
    assert best is not None
    return {"best_epoch": int(best["epoch"]), "best_metrics": best["metrics"], "best_state": best["state"], "history": history, "device": str(device)}


def train_fixed_epochs(
    X_train: np.ndarray,
    y_train: np.ndarray,
    g_train: np.ndarray,
    labels: list[str],
    cfg: dict[str, Any],
    variant: str,
    seed: int,
    epochs: int,
) -> tuple[torch.nn.Module, Standardizer, torch.device]:
    set_seed(seed)
    std = Standardizer.fit(X_train)
    X_train = std.transform(X_train)
    device = resolve_device(str(cfg["training"]["device"]))
    vcfg = variant_config(cfg, variant)
    model = build_model(cfg, len(labels)).to(device)
    optimizer = AdamW(model.parameters(), lr=float(cfg["training"]["learning_rate"]), weight_decay=float(cfg["training"]["weight_decay"]))
    loader = _make_loader(
        X_train, y_train, g_train,
        batch_size=int(cfg["training"]["batch_size"]),
        jitter=float(cfg["training"]["augmentation_jitter_std"]),
        subject_balanced=vcfg["subject_balanced"], shuffle=True,
    )
    sitting_idx, standing_idx = labels.index("sitting"), labels.index("standing")
    loss_cfg = dict(cfg["loss"])
    loss_cfg["supcon_weight"] = vcfg["supcon_weight"]
    loss_cfg["static_hn_weight"] = vcfg["static_hn_weight"]
    progress = tqdm(range(1, int(epochs) + 1), desc=f"{variant} retrain", unit="epoch", leave=False)
    for epoch in progress:
        stats = _epoch_train(
            model, loader, optimizer, device=device, loss_cfg=loss_cfg,
            sitting_idx=sitting_idx, standing_idx=standing_idx,
            grad_clip_norm=float(cfg["training"]["grad_clip_norm"]),
        )
        progress.set_postfix(epoch=epoch, loss=f"{stats['loss']:.4f}", ce=f"{stats['ce']:.4f}")
    return model, std, device


def save_checkpoint(path, model, standardizer: Standardizer, labels: list[str], metadata: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    torch.save({
        "model_state": model.state_dict(),
        "standardizer": standardizer.state(),
        "labels": labels,
        "metadata": metadata,
    }, path)


def load_checkpoint(path, cfg: dict[str, Any], map_location: str = "cpu"):
    payload = torch.load(path, map_location=map_location, weights_only=False)
    labels = list(payload["labels"])
    model = build_model(cfg, len(labels))
    model.load_state_dict(payload["model_state"])
    std = Standardizer(mean=payload["standardizer"]["mean"], std=payload["standardizer"]["std"])
    return model, std, labels, payload.get("metadata", {})
