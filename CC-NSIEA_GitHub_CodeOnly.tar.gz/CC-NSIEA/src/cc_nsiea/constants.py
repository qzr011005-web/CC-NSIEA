from __future__ import annotations

UCI_LABELS = (
    "walking",
    "walking_upstairs",
    "walking_downstairs",
    "sitting",
    "standing",
    "laying",
)

WISDM_LABELS = (
    "walking",
    "walking_upstairs",
    "walking_downstairs",
    "sitting",
    "standing",
)

STATIC_LABELS = ("sitting", "standing", "laying")
HARD_NEGATIVE_LABELS = ("sitting", "standing")
DYNAMIC_LABELS = ("walking", "walking_upstairs", "walking_downstairs")

UCI_NUMERIC_TO_LABEL = {
    1: "walking",
    2: "walking_upstairs",
    3: "walking_downstairs",
    4: "sitting",
    5: "standing",
    6: "laying",
}

WISDM_TO_COMMON = {
    "walking": "walking",
    "upstairs": "walking_upstairs",
    "downstairs": "walking_downstairs",
    "sitting": "sitting",
    "standing": "standing",
}
