# Reproducibility protocol

The committed protocol file `protocols/cc_nsiea_subject_cv.json` defines the
five outer subject-disjoint folds and the separate roles of model-training,
model-selection, audit-calibration, and outer-test subjects.

The primary result uses one shared neural perception model per outer fold.
D-NSIEA and CC-NSIEA operate on the same frozen out-of-fold neural predictions.
CC-NSIEA changes only the second-round evidence view: when the audit controller
requires refinement, it uses fixed predicted-class versus strongest-competitor
class contrast. The audit layer cannot override the neural label.

To regenerate the protocol rather than use the committed predeclared split:

```bash
python scripts/prepare_protocol.py --overwrite
python scripts/validate_setup.py
```

To reproduce the full final-method comparison, follow the commands in the
repository README. Generated files are written under `artifacts/`, `runs/`, and
`analysis/`; these directories are intentionally excluded from version control.

The optional language-model diagnostic is stored separately under `src/cc_nsiea/diagnostics/`; it is not required for the final CC-NSIEA method.
