#!/usr/bin/env python
"""Generic matched comparison for label-preserving evidence-audit controllers.

The comparison checks source-index, fold, subject, ground-truth and frozen
neural predictions before comparing audit-risk outputs. It never trains a model
or changes a controller output.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score, roc_auc_score

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from cc_nsiea.evidence_audit.metrics import aurc
from cc_nsiea.utils import write_json


def _safe_auc(error: np.ndarray, risk: np.ndarray) -> float | None:
    return None if len(np.unique(error)) < 2 else float(roc_auc_score(error, risk))


def _safe_ap(error: np.ndarray, risk: np.ndarray) -> float | None:
    return None if len(np.unique(error)) < 2 else float(average_precision_score(error, risk))


def _stats(error: np.ndarray, risk: np.ndarray) -> dict:
    return {
        "error_auroc": _safe_auc(error, risk),
        "error_auprc": _safe_ap(error, risk),
        "aurc": aurc(error, risk),
        "top_10pct_risk_error_rate": float(error[np.argsort(-risk, kind="stable")[:max(1, int(np.ceil(len(error) * 0.10))) ]].mean()),
    }


def main() -> None:
    p = argparse.ArgumentParser(description="Compare two matched label-preserving evidence-audit controller outputs.")
    p.add_argument("--left-oof", required=True)
    p.add_argument("--right-oof", required=True)
    p.add_argument("--left-name", required=True)
    p.add_argument("--right-name", required=True)
    p.add_argument("--output", required=True)
    args = p.parse_args()

    left = pd.read_csv(args.left_oof).sort_values("source_index").reset_index(drop=True)
    right = pd.read_csv(args.right_oof).sort_values("source_index").reset_index(drop=True)
    if len(left) != len(right):
        raise RuntimeError("Controller OOF files have different row counts.")
    key_cols = ["source_index", "fold", "subject_id", "ground_truth", "prediction", "label_source", "override_permitted"]
    for col in key_cols:
        if col not in left or col not in right or not left[col].equals(right[col]):
            raise RuntimeError(f"Matched comparison invalid: {col} differs.")
    if left["override_permitted"].astype(bool).any() or right["override_permitted"].astype(bool).any():
        raise RuntimeError("At least one controller permits label override.")
    if set(left["label_source"]) != {"neural_temporal_resnet"} or set(right["label_source"]) != {"neural_temporal_resnet"}:
        raise RuntimeError("Unexpected label source.")

    error = (left["prediction"].to_numpy(dtype=object) != left["ground_truth"].to_numpy(dtype=object)).astype(np.int64)
    left_risk = left["audit_risk"].to_numpy(dtype=np.float64)
    right_risk = right["audit_risk"].to_numpy(dtype=np.float64)
    l = _stats(error, left_risk)
    r = _stats(error, right_risk)
    diffs = {
        k: None if l[k] is None or r[k] is None else float(r[k] - l[k])
        for k in ["error_auroc", "error_auprc", "aurc", "top_10pct_risk_error_rate"]
    }
    exact_risk_equal = bool(np.array_equal(left_risk, right_risk))
    result = {
        "comparison_scope": "Same frozen neural predictions and protocol; only evidence-audit controller differs.",
        "n": int(len(left)),
        "subjects": int(left["subject_id"].nunique()),
        "prediction_identity_verified": True,
        "label_override_permitted": False,
        "left": {"name": args.left_name, **l},
        "right": {"name": args.right_name, **r},
        "right_minus_left": diffs,
        "audit_risk_exactly_identical": exact_risk_equal,
        "max_abs_audit_risk_difference": float(np.max(np.abs(right_risk - left_risk))),
        "action_distribution": {
            args.left_name: {str(k): int(v) for k, v in left["round1_action"].replace("", "not_invoked").value_counts(dropna=False).to_dict().items()},
            args.right_name: {str(k): int(v) for k, v in right["round1_action"].replace("", "not_invoked").value_counts(dropna=False).to_dict().items()},
        },
    }
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    write_json(output, result)
    print("MATCHED_AUDIT_CONTROLLER_COMPARISON_DONE")
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
