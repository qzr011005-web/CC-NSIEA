#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from cc_nsiea.data import label_to_index, load_uci_train_common_acceleration
from cc_nsiea.metrics import bootstrap_ci_accuracy_macro_f1, classification_metrics, expected_calibration_error
from cc_nsiea.protocol import validate_four_way_audit_protocol
from cc_nsiea.train import Standardizer, predict, save_checkpoint, select_epoch, train_fixed_epochs
from cc_nsiea.utils import ensure_dir, load_yaml, read_json, resolve_paths, sha256_file, write_json


def _save_inputs(path: Path, *, X: np.ndarray, pred: dict, source_indices: np.ndarray) -> None:
    np.savez_compressed(
        path,
        X=np.asarray(X, dtype=np.float32),
        embeddings=np.asarray(pred["embeddings"], dtype=np.float32),
        probabilities=np.asarray(pred["probabilities"], dtype=np.float64),
        y_idx=np.asarray(pred["y_idx"], dtype=np.int64),
        y_label=np.asarray(pred["y_label"], dtype="U32"),
        pred_label=np.asarray(pred["pred_label"], dtype="U32"),
        subject_ids=np.asarray(pred["groups"], dtype=np.int64),
        source_indices=np.asarray(source_indices, dtype=np.int64),
    )


def main() -> None:
    parser = argparse.ArgumentParser(description="Train the shared label-preserving E0 perception model once for D-NSIEA and CC-NSIEA.")
    parser.add_argument("--config", default="configs/cc_nsiea_uci.yaml")
    parser.add_argument("--protocol", default="protocols/cc_nsiea_subject_cv.json")
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args()

    cfg = resolve_paths(load_yaml(args.config), ROOT)
    protocol = read_json(args.protocol)
    validate_four_way_audit_protocol(protocol)
    if protocol.get("official_test_labels_used") is not False:
        raise RuntimeError("Official UCI HAR test labels must not be used.")
    if bool(cfg["evidence_audit"]["label_override_permitted"]):
        raise RuntimeError("Final framework must prohibit label override.")

    labels = list(cfg["data"]["labels"])
    static_labels = list(cfg["evaluation"]["static_labels"])
    data = load_uci_train_common_acceleration(cfg["paths"]["data_dir"])
    y_idx = label_to_index(data.y, labels)

    run_root = Path(cfg["paths"]["run_dir"]) / "uci_cc_nsiea_perception"
    art_root = Path(cfg["paths"]["artifact_dir"]) / "uci_cc_nsiea_perception"
    analysis_root = Path(cfg["paths"]["analysis_dir"]) / "uci_cc_nsiea_perception"
    if run_root.exists() and not args.overwrite:
        raise FileExistsError(f"{run_root} exists. Use --overwrite only for a fresh rerun.")
    ensure_dir(run_root)
    ensure_dir(art_root)
    ensure_dir(analysis_root)

    oof_rows: list[dict] = []
    fold_rows: list[dict] = []
    manifest_folds: list[dict] = []

    for fold in protocol["folds"]:
        fold_id = int(fold["fold"])
        print(f"[SHARED-PERCEPTION] Fold {fold_id + 1}/{len(protocol['folds'])}: select E0 epoch", flush=True)
        idx_train = np.asarray(fold["model_train_indices"], dtype=np.int64)
        idx_sel = np.asarray(fold["model_selection_indices"], dtype=np.int64)
        idx_cal = np.asarray(fold["audit_calibration_indices"], dtype=np.int64)
        idx_test = np.asarray(fold["outer_test_indices"], dtype=np.int64)
        idx_memory = np.concatenate([idx_train, idx_sel])

        select_std = Standardizer.fit(data.X[idx_train])
        selection = select_epoch(
            select_std.transform(data.X[idx_train]), y_idx[idx_train], data.groups[idx_train],
            select_std.transform(data.X[idx_sel]), y_idx[idx_sel], data.groups[idx_sel],
            labels, cfg, "e0", seed=int(cfg["seed"]) + fold_id,
        )
        selected_epoch = min(int(selection["best_epoch"]), int(cfg["training"]["final_epochs_cap"]))

        print(f"[SHARED-PERCEPTION] Fold {fold_id + 1}: retrain E0 for {selected_epoch} epochs", flush=True)
        model, std, device = train_fixed_epochs(
            data.X[idx_memory], y_idx[idx_memory], data.groups[idx_memory], labels,
            cfg, "e0", seed=int(cfg["seed"]) + 10_000 + fold_id, epochs=selected_epoch,
        )
        fold_art = ensure_dir(art_root / f"fold_{fold_id}")
        save_checkpoint(
            fold_art / "temporal_resnet_e0.pt",
            model,
            std,
            labels,
            metadata={
                "fold": fold_id,
                "selected_epoch": selected_epoch,
                "variant": "e0",
                "label_override_permitted": False,
                "protocol": protocol["protocol"],
            },
        )

        memory_X = std.transform(data.X[idx_memory])
        cal_X = std.transform(data.X[idx_cal])
        test_X = std.transform(data.X[idx_test])
        memory_pred = predict(model, memory_X, y_idx[idx_memory], data.groups[idx_memory], labels, batch_size=int(cfg["training"]["eval_batch_size"]), device=device)
        cal_pred = predict(model, cal_X, y_idx[idx_cal], data.groups[idx_cal], labels, batch_size=int(cfg["training"]["eval_batch_size"]), device=device)
        test_pred = predict(model, test_X, y_idx[idx_test], data.groups[idx_test], labels, batch_size=int(cfg["training"]["eval_batch_size"]), device=device)

        _save_inputs(fold_art / "memory_inputs.npz", X=memory_X, pred=memory_pred, source_indices=idx_memory)
        _save_inputs(fold_art / "calibration_inputs.npz", X=cal_X, pred=cal_pred, source_indices=idx_cal)
        _save_inputs(fold_art / "test_inputs.npz", X=test_X, pred=test_pred, source_indices=idx_test)
        write_json(fold_art / "motion_rule_training_metadata.json", {
            "fitted_from": "memory_inputs_only",
            "memory_subjects": fold["model_train_subjects"] + fold["model_selection_subjects"],
        })

        metric = classification_metrics(test_pred["y_label"], test_pred["pred_label"], labels, static_labels)
        ece = expected_calibration_error(test_pred["probabilities"], test_pred["y_idx"])
        fold_rows.append({
            "fold": fold_id,
            "n_test": int(len(idx_test)),
            "selected_epoch": selected_epoch,
            "ece": ece,
            **{k: v for k, v in metric.items() if k not in {"confusion", "labels"}},
        })
        for pos in range(len(idx_test)):
            row = {
                "source_index": int(idx_test[pos]),
                "fold": fold_id,
                "subject_id": int(test_pred["groups"][pos]),
                "ground_truth": str(test_pred["y_label"][pos]),
                "prediction": str(test_pred["pred_label"][pos]),
                "confidence": float(np.max(test_pred["probabilities"][pos])),
                "entropy": float(-(test_pred["probabilities"][pos] * np.log(np.maximum(test_pred["probabilities"][pos], 1e-12))).sum()),
                "label_source": "neural_temporal_resnet",
                "override_permitted": False,
            }
            for ci, label in enumerate(labels):
                row[f"prob_{label}"] = float(test_pred["probabilities"][pos, ci])
            oof_rows.append(row)

        manifest_folds.append({
            "fold": fold_id,
            "selected_epoch": selected_epoch,
            "checkpoint": str((fold_art / "temporal_resnet_e0.pt").relative_to(ROOT)),
            "memory_n": int(len(idx_memory)),
            "calibration_n": int(len(idx_cal)),
            "outer_test_n": int(len(idx_test)),
            "model_train_subjects": fold["model_train_subjects"],
            "model_selection_subjects": fold["model_selection_subjects"],
            "audit_calibration_subjects": fold["audit_calibration_subjects"],
            "outer_test_subjects": fold["outer_test_subjects"],
        })
        print(json.dumps(fold_rows[-1], sort_keys=True), flush=True)

    oof = pd.DataFrame(oof_rows).sort_values("source_index")
    if len(oof) != len(data.X) or oof["source_index"].nunique() != len(data.X):
        raise RuntimeError("Shared OOF prediction coverage is incomplete or duplicated.")
    if oof["override_permitted"].astype(bool).any() or set(oof["label_source"]) != {"neural_temporal_resnet"}:
        raise RuntimeError("Shared perception integrity invariant failed.")
    oof.to_csv(run_root / "shared_oof_perception_predictions.csv", index=False)
    pd.DataFrame(fold_rows).to_csv(analysis_root / "fold_metrics.csv", index=False)

    total = classification_metrics(oof["ground_truth"].to_numpy(), oof["prediction"].to_numpy(), labels, static_labels)
    ci = bootstrap_ci_accuracy_macro_f1(
        oof["ground_truth"].to_numpy(), oof["prediction"].to_numpy(), labels,
        iterations=int(cfg["evaluation"]["bootstrap_iterations"]), seed=int(cfg["seed"]),
    )
    summary = {
        "method": "shared_temporal_resnet_e0",
        "n_oof": int(len(oof)),
        **{k: v for k, v in total.items() if k not in {"confusion", "labels"}},
        **ci,
        "mean_confidence": float(oof["confidence"].mean()),
        "mean_entropy": float(oof["entropy"].mean()),
        "official_test_labels_used": False,
        "subject_disjoint": True,
        "label_override_permitted": False,
        "label_source": "neural_temporal_resnet",
        "confusion": total["confusion"],
        "labels": labels,
    }
    write_json(analysis_root / "summary.json", summary)
    manifest = {
        "schema_version": "shared_perception_v1",
        "config_path": str(Path(args.config)),
        "protocol_path": str(Path(args.protocol)),
        "config_sha256": sha256_file(args.config),
        "protocol_sha256": sha256_file(args.protocol),
        "official_test_labels_used": False,
        "label_override_permitted": False,
        "neural_variant": "e0_cross_entropy_only",
        "folds": manifest_folds,
    }
    write_json(run_root / "shared_perception_manifest.json", manifest)
    print("SHARED_PERCEPTION_CV_DONE")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
