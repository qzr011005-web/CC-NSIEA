#!/usr/bin/env python
from __future__ import annotations

import argparse
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from cc_nsiea.data import load_uci_train_common_acceleration
from cc_nsiea.protocol import validate_four_way_audit_protocol
from cc_nsiea.utils import load_yaml, read_json, resolve_paths


def main() -> None:
    parser = argparse.ArgumentParser(description="Validate final evidence-audit data and protocol integrity.")
    parser.add_argument("--config", default="configs/cc_nsiea_uci.yaml")
    parser.add_argument("--protocol", default="protocols/cc_nsiea_subject_cv.json")
    args = parser.parse_args()

    cfg = resolve_paths(load_yaml(args.config), ROOT)
    protocol = read_json(args.protocol)
    data = load_uci_train_common_acceleration(cfg["paths"]["data_dir"])
    validate_four_way_audit_protocol(protocol)
    if int(protocol["n_samples"]) != len(data.X):
        raise AssertionError("Protocol sample count does not match UCI official training split.")
    if protocol.get("official_test_labels_used") is not False:
        raise AssertionError("Protocol must declare official_test_labels_used=false.")
    if bool(cfg["evidence_audit"]["label_override_permitted"]):
        raise AssertionError("Final evidence audit may not permit label override.")
    if float(sum(cfg["evidence_audit"]["aggregation_weights"].values())) <= 0:
        raise AssertionError("Audit aggregation weights must be positive.")
    print("FINAL_AUDIT_SETUP_VALIDATED")
    print(f"uci_train_rows={len(data.X)}")
    print(f"uci_train_subjects={len(set(data.groups.tolist()))}")
    print("official_test_labels_used=false")
    print("label_override_permitted=false")


if __name__ == "__main__":
    main()
