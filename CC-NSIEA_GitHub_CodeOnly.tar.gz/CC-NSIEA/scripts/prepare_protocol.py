#!/usr/bin/env python
from __future__ import annotations

import argparse
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from cc_nsiea.data import load_uci_train_common_acceleration
from cc_nsiea.protocol import build_four_way_subject_audit_protocol, validate_four_way_audit_protocol
from cc_nsiea.utils import load_yaml, resolve_paths, write_json


def main() -> None:
    parser = argparse.ArgumentParser(description="Create a four-way subject-disjoint evidence-audit protocol.")
    parser.add_argument("--config", default="configs/cc_nsiea_uci.yaml")
    parser.add_argument("--output", default="protocols/cc_nsiea_subject_cv.json")
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args()

    out = Path(args.output)
    if out.exists() and not args.overwrite:
        raise FileExistsError(f"{out} already exists. Use --overwrite only before running the final evaluation.")
    cfg = resolve_paths(load_yaml(args.config), ROOT)
    data = load_uci_train_common_acceleration(cfg["paths"]["data_dir"])
    p = cfg["protocol"]
    protocol = build_four_way_subject_audit_protocol(
        data.y,
        data.groups,
        list(cfg["data"]["labels"]),
        outer_folds=int(p["outer_folds"]),
        model_selection_subjects=int(p["model_selection_subjects_per_fold"]),
        audit_calibration_subjects=int(p["audit_calibration_subjects_per_fold"]),
        seed=int(cfg["seed"]),
        trials=int(p["split_trials"]),
    )
    protocol["dataset_source"] = data.source
    protocol["official_test_labels_used"] = False
    validate_four_way_audit_protocol(protocol)
    write_json(out, protocol)
    print("CC_NSIEA_PROTOCOL_DONE")
    print(f"output: {out}")
    for fold in protocol["folds"]:
        print(
            "fold={fold} train={train} selection={sel} audit_calibration={cal} outer_test={test}".format(
                fold=fold["fold"],
                train=fold["model_train_subjects"],
                sel=fold["model_selection_subjects"],
                cal=fold["audit_calibration_subjects"],
                test=fold["outer_test_subjects"],
            )
        )


if __name__ == "__main__":
    main()
