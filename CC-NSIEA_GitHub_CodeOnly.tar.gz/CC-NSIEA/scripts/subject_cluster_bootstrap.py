#!/usr/bin/env python
"""Subject-cluster bootstrap for paired evidence-audit controller metrics.

A cluster is one UCI HAR subject. Each bootstrap replicate samples the observed
subjects with replacement and carries all of each selected subject's windows.
This respects within-subject dependence that a window-level bootstrap ignores.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score, roc_auc_score

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from cc_nsiea.evidence_audit.metrics import aurc
from cc_nsiea.utils import write_json


def _safe_auc(error: np.ndarray, risk: np.ndarray) -> float | None:
    return None if len(np.unique(error)) < 2 else float(roc_auc_score(error, risk))


def _safe_ap(error: np.ndarray, risk: np.ndarray) -> float | None:
    return None if len(np.unique(error)) < 2 else float(average_precision_score(error, risk))


def _metric_bundle(error: np.ndarray, risk: np.ndarray) -> dict[str, float | None]:
    return {
        "error_auroc": _safe_auc(error, risk),
        "error_auprc": _safe_ap(error, risk),
        "aurc": aurc(error, risk),
    }


def _validate_pair(left: pd.DataFrame, right: pd.DataFrame) -> None:
    if len(left) != len(right):
        raise RuntimeError("OOF row counts differ.")
    for col in ["source_index", "fold", "subject_id", "ground_truth", "prediction", "label_source", "override_permitted"]:
        if col not in left.columns or col not in right.columns or not left[col].equals(right[col]):
            raise RuntimeError(f"Paired clustered inference invalid: {col} differs.")
    if left["override_permitted"].astype(bool).any() or right["override_permitted"].astype(bool).any():
        raise RuntimeError("A controller allowed label override.")


def _bootstrap(error: np.ndarray, risk_left: np.ndarray, risk_right: np.ndarray, subject: np.ndarray, *, iterations: int, seed: int) -> tuple[dict, np.ndarray]:
    subjects = np.asarray(sorted(pd.unique(subject)), dtype=np.int64)
    subject_index = {int(s): np.flatnonzero(subject == s) for s in subjects}
    rng = np.random.default_rng(seed)
    deltas = []
    skipped = 0
    for _ in range(int(iterations)):
        sampled = rng.choice(subjects, size=len(subjects), replace=True)
        indices = np.concatenate([subject_index[int(s)] for s in sampled])
        e = error[indices]
        if len(np.unique(e)) < 2:
            skipped += 1
            continue
        l = _metric_bundle(e, risk_left[indices])
        r = _metric_bundle(e, risk_right[indices])
        if any(l[k] is None or r[k] is None for k in l):
            skipped += 1
            continue
        deltas.append([float(r["error_auroc"] - l["error_auroc"]), float(r["error_auprc"] - l["error_auprc"]), float(r["aurc"] - l["aurc"])])
    values = np.asarray(deltas, dtype=np.float64)
    if len(values) == 0:
        raise RuntimeError("No valid subject-cluster bootstrap replicate contained both correct and incorrect predictions.")
    labels = ["error_auroc", "error_auprc", "aurc"]
    result = {
        "bootstrap_unit": "subject_id",
        "bootstrap_scheme": "resample all observed subjects with replacement; retain all windows within each sampled subject",
        "requested_iterations": int(iterations),
        "valid_iterations": int(len(values)),
        "skipped_iterations": int(skipped),
        "n_subjects": int(len(subjects)),
        "n_windows": int(len(error)),
        "right_minus_left": {},
    }
    for col, label in enumerate(labels):
        x = values[:, col]
        result["right_minus_left"][label] = {
            "mean": float(np.mean(x)),
            "median": float(np.median(x)),
            "ci95": [float(np.quantile(x, 0.025)), float(np.quantile(x, 0.975))],
        }
    return result, values


def main() -> None:
    p = argparse.ArgumentParser(description="Run paired subject-cluster bootstrap and fold-level comparison for two evidence-audit controllers.")
    p.add_argument("--left-oof", required=True)
    p.add_argument("--right-oof", required=True)
    p.add_argument("--left-name", required=True)
    p.add_argument("--right-name", required=True)
    p.add_argument("--iterations", type=int, default=10000)
    p.add_argument("--seed", type=int, default=2030)
    p.add_argument("--output-json", required=True)
    p.add_argument("--fold-output-csv", required=True)
    args = p.parse_args()

    left = pd.read_csv(args.left_oof).sort_values("source_index").reset_index(drop=True)
    right = pd.read_csv(args.right_oof).sort_values("source_index").reset_index(drop=True)
    _validate_pair(left, right)
    error = (left["prediction"].to_numpy(dtype=object) != left["ground_truth"].to_numpy(dtype=object)).astype(np.int64)
    risk_left = left["audit_risk"].to_numpy(dtype=np.float64)
    risk_right = right["audit_risk"].to_numpy(dtype=np.float64)
    subject = left["subject_id"].to_numpy(dtype=np.int64)

    left_total = _metric_bundle(error, risk_left)
    right_total = _metric_bundle(error, risk_right)
    boot, values = _bootstrap(error, risk_left, risk_right, subject, iterations=args.iterations, seed=args.seed)

    rows=[]
    for fold_id in sorted(left["fold"].unique()):
        mask = left["fold"].to_numpy() == fold_id
        lf=_metric_bundle(error[mask], risk_left[mask])
        rf=_metric_bundle(error[mask], risk_right[mask])
        rows.append({
            "fold": int(fold_id),
            "n_windows": int(mask.sum()),
            "n_subjects": int(left.loc[mask, "subject_id"].nunique()),
            "left_error_auroc": lf["error_auroc"],
            "right_error_auroc": rf["error_auroc"],
            "right_minus_left_error_auroc": None if lf["error_auroc"] is None or rf["error_auroc"] is None else float(rf["error_auroc"]-lf["error_auroc"]),
            "left_error_auprc": lf["error_auprc"],
            "right_error_auprc": rf["error_auprc"],
            "right_minus_left_error_auprc": None if lf["error_auprc"] is None or rf["error_auprc"] is None else float(rf["error_auprc"]-lf["error_auprc"]),
            "left_aurc": lf["aurc"],
            "right_aurc": rf["aurc"],
            "right_minus_left_aurc": float(rf["aurc"]-lf["aurc"]),
        })
    fold_frame=pd.DataFrame(rows)
    fold_output=Path(args.fold_output_csv); fold_output.parent.mkdir(parents=True, exist_ok=True); fold_frame.to_csv(fold_output,index=False)

    out={
        "comparison_scope": "Paired label-preserving audit-controller comparison; all windows of a subject remain together in subject-cluster bootstrap resampling.",
        "left_name": args.left_name,
        "right_name": args.right_name,
        "prediction_identity_verified": True,
        "n_windows": int(len(left)),
        "n_subjects": int(left["subject_id"].nunique()),
        "left_metrics": left_total,
        "right_metrics": right_total,
        "point_delta_right_minus_left": {k: None if left_total[k] is None or right_total[k] is None else float(right_total[k]-left_total[k]) for k in left_total},
        "subject_cluster_bootstrap": boot,
        "fold_level_summary": {
            "n_folds": int(len(fold_frame)),
            "auprc_positive_folds": int((fold_frame["right_minus_left_error_auprc"] > 0).sum()),
            "auprc_zero_folds": int((fold_frame["right_minus_left_error_auprc"] == 0).sum()),
            "auprc_negative_folds": int((fold_frame["right_minus_left_error_auprc"] < 0).sum()),
        },
        "fold_metrics_csv": str(fold_output),
    }
    output=Path(args.output_json); output.parent.mkdir(parents=True, exist_ok=True); write_json(output,out)
    print("SUBJECT_CLUSTER_BOOTSTRAP_DONE")
    print(json.dumps(out,ensure_ascii=False,indent=2))


if __name__ == '__main__':
    main()
