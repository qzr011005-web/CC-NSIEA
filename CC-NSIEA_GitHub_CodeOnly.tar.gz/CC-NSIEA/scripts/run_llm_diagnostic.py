#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys
import time

import numpy as np
import pandas as pd
from tqdm.auto import tqdm

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from cc_nsiea.evidence_audit.controller import AuditControllerConfig, calibrate_tau_threshold
from cc_nsiea.evidence_audit.guided_controller import GuidedAuditControllerConfig, GuidedEvidenceAuditController
from cc_nsiea.evidence_audit.kpc import kpc_completeness, write_jsonl
from cc_nsiea.evidence_audit.metrics import bootstrap_auprc_delta, evaluate_risk_estimators
from cc_nsiea.diagnostics.llm_planner import LLMActionPlanner
from cc_nsiea.evidence_audit.planner import DeterministicActionPlanner, FixedClassContrastPlanner
from cc_nsiea.evidence_audit.retrieval import build_evidence_memory
from cc_nsiea.evidence_audit.rules import MotionEnergyRule, fit_motion_energy_rule
from cc_nsiea.metrics import classification_metrics
from cc_nsiea.protocol import validate_four_way_audit_protocol
from cc_nsiea.utils import ensure_dir, load_yaml, read_json, resolve_paths, sha256_file, write_json


def _load_npz(path: Path) -> dict[str, np.ndarray]:
    with np.load(path, allow_pickle=False) as obj:
        return {k: obj[k] for k in obj.files}


def _inputs(payload: dict[str, np.ndarray], fold: int) -> dict:
    return {
        "sample_ids": payload["source_indices"].astype(np.int64),
        "subject_ids": payload["subject_ids"].astype(np.int64),
        "X": payload["X"].astype(np.float32),
        "embeddings": payload["embeddings"].astype(np.float32),
        "probabilities": payload["probabilities"].astype(np.float64),
        "ground_truth": payload["y_label"].astype("U32"),
        "fold": int(fold),
    }


def _make_controller(*, tau: float, cfg: dict, memory, motion_rule, labels: list[str], planner, controller_name: str) -> GuidedEvidenceAuditController:
    a = cfg["evidence_audit"]
    audit_cfg = GuidedAuditControllerConfig(
        round0_top_k_global=int(a["round0_top_k_global"]),
        round1_top_k_global=int(a["round1_top_k_global"]),
        top_k_class_conditioned=int(a["top_k_class_conditioned"]),
        max_iterations=int(a["max_iterations"]),
        evidence_gain_epsilon=float(a["evidence_gain_epsilon"]),
        tau_stop=float(tau),
        aggregation_weights={str(k): float(v) for k, v in a["aggregation_weights"].items()},
    )
    return GuidedEvidenceAuditController(
        memory=memory,
        motion_rule=motion_rule,
        labels=labels,
        cfg=audit_cfg,
        planner=planner,
        controller_name=controller_name,
    )


def _record_to_row(record: dict) -> dict:
    final_round = record["retrieval_rounds"][-1]
    rules = {r["rule_name"]: r for r in record["rule_results"]}
    decision = record.get("planner_decision") or {}
    return {
        "source_index": int(record["sample_id"]),
        "fold": int(record["fold"]),
        "subject_id": int(record["subject_id"]),
        "ground_truth": str(record["ground_truth_available_for_evaluation_only"]),
        "prediction": str(record["predicted_label"]),
        "confidence": float(record["confidence"]),
        "entropy": float(record["entropy"]),
        "top_competing_class": str(record["top_competing_class"]),
        "audit_risk": float(record["audit_risk"]),
        "retrieval_risk": float(1.0 - final_round["retrieval_support"]),
        "rule_risk": float(1.0 - final_round["rule_consistency"]),
        "tau_final": float(record["tau_history"][-1]),
        "iterations": int(record["iteration_count"]),
        "evidence_gain": float(record["evidence_gain"]),
        "audit_status": str(record["audit_status"]),
        "stop_reason": str(record["stop_reason"]),
        "data_validity_status": str(rules["data_validity"]["status"]),
        "motion_rule_status": str(rules["motion_group_coherence"]["status"]),
        "retrieval_rule_status": str(rules["retrieval_support"]["status"]),
        "separation_rule_status": str(rules["contrastive_separation"]["status"]),
        "controller_name": str(record["controller_name"]),
        "planner_invoked": bool(record["planner_invoked"]),
        "round1_action": "" if record.get("round1_action") is None else str(record["round1_action"]),
        "planner_status": "not_invoked" if not decision else str(decision["decision_status"]),
        "planner_fallback_used": bool(decision.get("fallback_used", False)),
        "planner_cache_hit": bool(decision.get("cache_hit", False)),
        "planner_api_latency_ms": float(decision["api_latency_ms"]) if decision.get("api_latency_ms") is not None else np.nan,
        "override_permitted": bool(record["override_permitted"]),
        "label_source": str(record["label_source"]),
    }


def _load_deterministic_taus(path: Path) -> dict[int, float]:
    rows = read_json(path)
    if not isinstance(rows, list):
        raise ValueError("Deterministic tau-selection file must be a JSON list.")
    out = {int(row["fold"]): float(row["selected_tau"]) for row in rows}
    if len(out) != 5:
        raise ValueError("Expected a selected tau for every outer fold.")
    return out


def _cache_dir(cfg: dict, fold: int) -> Path:
    configured = Path(str(cfg["llm_controller"]["cache_dir"]))
    root = configured if configured.is_absolute() else ROOT / configured
    return root / f"fold_{fold}"


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the optional constrained L-NSIEA diagnostic control on frozen neural predictions.")
    parser.add_argument("--config", default="configs/llm_diagnostic_uci.yaml")
    parser.add_argument("--protocol", default="protocols/cc_nsiea_subject_cv.json")
    parser.add_argument("--perception-run", default="runs/uci_cc_nsiea_perception")
    parser.add_argument("--controller", choices=["llm"], required=True)
    parser.add_argument("--deterministic-tau-selection", default=None, help="Required for --controller llm or class_contrast; created by the deterministic controller run.")
    parser.add_argument("--llm-cache-mode", choices=["read_write", "read_only", "disabled"], default=None)
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args()

    cfg = resolve_paths(load_yaml(args.config), ROOT)
    protocol = read_json(args.protocol)
    validate_four_way_audit_protocol(protocol)
    if protocol.get("official_test_labels_used") is not False:
        raise RuntimeError("Official UCI HAR test labels must not be used.")
    if bool(cfg["evidence_audit"]["label_override_permitted"]):
        raise RuntimeError("Label override must remain disabled.")

    labels = list(cfg["data"]["labels"])
    static_labels = list(cfg["evaluation"]["static_labels"])
    perception_run = Path(args.perception_run)
    if not perception_run.is_absolute():
        perception_run = ROOT / perception_run
    perception_manifest = read_json(perception_run / "shared_perception_manifest.json")
    if perception_manifest.get("label_override_permitted") is not False:
        raise RuntimeError("Shared perception manifest violates the no-override invariant.")

    base_run = Path(cfg["paths"]["run_dir"]) / "uci_cc_nsiea_audit" / args.controller
    base_analysis = Path(cfg["paths"]["analysis_dir"]) / "uci_cc_nsiea_audit" / args.controller
    if base_run.exists() and not args.overwrite:
        raise FileExistsError(f"{base_run} exists. Use --overwrite only for a fresh rerun.")
    ensure_dir(base_run)
    ensure_dir(base_analysis)

    tau_rows: list[dict] = []
    if args.controller == "llm":
        if args.deterministic_tau_selection is None:
            raise ValueError("--deterministic-tau-selection is required for the L-NSIEA diagnostic control.")
        tau_path = Path(args.deterministic_tau_selection)
        if not tau_path.is_absolute():
            tau_path = ROOT / tau_path
        selected_taus = _load_deterministic_taus(tau_path)
        tau_source = {
            "mode": "shared_deterministic_calibration",
            "path": str(tau_path),
            "sha256": sha256_file(tau_path),
        }
    else:
        selected_taus = {}
        tau_source = {"mode": "to_be_calibrated_deterministically"}

    all_kpc: list[dict] = []
    oof_rows: list[dict] = []
    fold_rows: list[dict] = []
    planner_stats_by_fold: list[dict] = []
    started_all = time.perf_counter()

    for fold in protocol["folds"]:
        fold_id = int(fold["fold"])
        # Saved neural artifacts are parallel to the configured artifact root.
        art_root = Path(cfg["paths"]["artifact_dir"]) / "uci_cc_nsiea_perception" / f"fold_{fold_id}"
        memory_payload = _load_npz(art_root / "memory_inputs.npz")
        cal_payload = _load_npz(art_root / "calibration_inputs.npz")
        test_payload = _load_npz(art_root / "test_inputs.npz")
        memory = build_evidence_memory(
            memory_payload["embeddings"], memory_payload["y_idx"], memory_payload["source_indices"], memory_payload["subject_ids"], len(labels)
        )
        motion_rule = fit_motion_energy_rule(memory_payload["X"], memory_payload["y_label"])

        llm_cfg = cfg["llm_controller"]
        planner = LLMActionPlanner(
            model=str(llm_cfg["model"]),
            base_url=str(llm_cfg["base_url"]),
            api_key_env=str(llm_cfg["api_key_env"]),
            temperature=float(llm_cfg["temperature"]),
            max_tokens=int(llm_cfg["max_tokens"]),
            timeout_seconds=float(llm_cfg["timeout_seconds"]),
            max_retries=int(llm_cfg["max_retries"]),
            cache_dir=_cache_dir(cfg, fold_id),
            cache_mode=str(args.llm_cache_mode or llm_cfg["cache_mode"]),
            max_live_calls=int(llm_cfg["max_live_calls_per_fold"]),
            fallback_action=str(llm_cfg["fallback_action"]),
        )
        controller = _make_controller(
            tau=selected_taus[fold_id], cfg=cfg, memory=memory, motion_rule=motion_rule, labels=labels,
            planner=planner, controller_name="L-NSIEA",
        )
        tau_rows.append({
            "fold": fold_id,
            "selected_tau": selected_taus[fold_id],
            "calibration_subjects": fold["audit_calibration_subjects"],
            "selection_metric": "reused_deterministic_calibration",
        })

        print(f"[{args.controller.upper()}-AUDIT] Fold {fold_id + 1}/{len(protocol['folds'])}: tau={selected_taus[fold_id]:.2f}; auditing frozen outer-test predictions", flush=True)
        test_inputs = _inputs(test_payload, fold_id)
        records: list[dict] = []
        for j in tqdm(range(len(test_inputs["sample_ids"])), desc=f"{args.controller} fold {fold_id} audit", unit="sample"):
            one = {k: (v[j:j+1] if isinstance(v, np.ndarray) else v) for k, v in test_inputs.items()}
            records.extend(controller.audit_batch(**one))
        all_kpc.extend(records)
        rows = [_record_to_row(row) for row in records]
        oof_rows.extend(rows)

        y_true = np.asarray([row["ground_truth_available_for_evaluation_only"] for row in records], dtype=object)
        y_pred = np.asarray([row["predicted_label"] for row in records], dtype=object)
        fold_metric = classification_metrics(y_true, y_pred, labels, static_labels)
        fold_reliability = evaluate_risk_estimators(
            y_true=y_true,
            pred=y_pred,
            confidence=np.asarray([row["confidence"] for row in records], dtype=np.float64),
            entropy=np.asarray([row["entropy"] for row in records], dtype=np.float64),
            retrieval_risk=np.asarray([1.0 - row["retrieval_rounds"][-1]["retrieval_support"] for row in records], dtype=np.float64),
            rule_risk=np.asarray([1.0 - row["retrieval_rounds"][-1]["rule_consistency"] for row in records], dtype=np.float64),
            audit_risk=np.asarray([row["audit_risk"] for row in records], dtype=np.float64),
        )
        fold_summary = {
            "fold": fold_id,
            "n_test": int(len(records)),
            "selected_tau": selected_taus[fold_id],
            **{k: v for k, v in fold_metric.items() if k not in {"confusion", "labels"}},
            "audit_auprc": fold_reliability["estimators"]["proposed_audit_risk"]["error_auprc"],
            "confidence_auprc": fold_reliability["estimators"]["confidence_only"]["error_auprc"],
            "audit_aurc": fold_reliability["estimators"]["proposed_audit_risk"]["aurc"],
            "confidence_aurc": fold_reliability["estimators"]["confidence_only"]["aurc"],
            "mean_iterations": float(np.mean([row["iteration_count"] for row in records])),
            "planner_invocations": int(sum(row["planner_invoked"] for row in records)),
            "planner_fallbacks": int(sum(bool((row.get("planner_decision") or {}).get("fallback_used", False)) for row in records)),
        }
        fold_rows.append(fold_summary)
        if hasattr(planner, "stats"):
            planner_stats_by_fold.append({"fold": fold_id, **planner.stats()})
        else:
            planner_stats_by_fold.append({"fold": fold_id, "live_calls": 0, "cache_hits": 0, "fallbacks": 0})
        print(json.dumps(fold_summary, sort_keys=True), flush=True)

    oof = pd.DataFrame(oof_rows).sort_values("source_index")
    if oof["source_index"].nunique() != len(oof) or len(oof) == 0:
        raise RuntimeError("Controller OOF coverage is incomplete or duplicated.")
    shared = pd.read_csv(perception_run / "shared_oof_perception_predictions.csv").sort_values("source_index")
    required = ["source_index", "ground_truth", "prediction", "label_source", "override_permitted"]
    if not oof[required].reset_index(drop=True).equals(shared[required].reset_index(drop=True)):
        raise RuntimeError("Audit controller changed, reordered, or mismatched the frozen neural predictions.")
    if oof["override_permitted"].astype(bool).any() or set(oof["label_source"].unique()) != {"neural_temporal_resnet"}:
        raise RuntimeError("No-override integrity invariant failed.")

    oof.to_csv(base_run / "oof_audit_predictions.csv", index=False)
    all_kpc = sorted(all_kpc, key=lambda row: int(row["sample_id"]))
    write_jsonl(base_run / "kpc_records.jsonl", all_kpc)
    pd.DataFrame(fold_rows).to_csv(base_analysis / "fold_metrics.csv", index=False)
    write_json(base_analysis / "tau_selection.json", tau_rows)
    write_json(base_analysis / "planner_stats.json", planner_stats_by_fold)

    total = classification_metrics(oof["ground_truth"].to_numpy(), oof["prediction"].to_numpy(), labels, static_labels)
    reliability = evaluate_risk_estimators(
        y_true=oof["ground_truth"].to_numpy(),
        pred=oof["prediction"].to_numpy(),
        confidence=oof["confidence"].to_numpy(),
        entropy=oof["entropy"].to_numpy(),
        retrieval_risk=oof["retrieval_risk"].to_numpy(),
        rule_risk=oof["rule_risk"].to_numpy(),
        audit_risk=oof["audit_risk"].to_numpy(),
    )
    bootstrap = bootstrap_auprc_delta(
        y_true=oof["ground_truth"].to_numpy(), pred=oof["prediction"].to_numpy(),
        confidence=oof["confidence"].to_numpy(), audit_risk=oof["audit_risk"].to_numpy(),
        iterations=int(cfg["evaluation"]["bootstrap_iterations"]), seed=int(cfg["seed"]) + 77,
    )
    kpc_stats = kpc_completeness(all_kpc)
    total_runtime = time.perf_counter() - started_all
    summary = {
        "controller": "L-NSIEA",
        "n_oof": int(len(oof)),
        "neural_perception_source": str(perception_run / "shared_oof_perception_predictions.csv"),
        "neural_predictions_frozen_and_identical": True,
        "official_test_labels_used": False,
        "subject_disjoint": True,
        "label_override_permitted": False,
        "label_source": "neural_temporal_resnet",
        "tau_source": tau_source,
        "mean_audit_iterations": float(oof["iterations"].mean()),
        "total_audit_runtime_seconds": float(total_runtime),
        "reliability": reliability,
        "bootstrap_audit_vs_confidence": bootstrap,
        "kpc_completeness": kpc_stats,
        "planner_stats_by_fold": planner_stats_by_fold,
        "planner_status_distribution": {str(k): int(v) for k, v in oof["planner_status"].value_counts(dropna=False).to_dict().items()},
        "round1_action_distribution": {str(k): int(v) for k, v in oof["round1_action"].replace("", "not_invoked").value_counts(dropna=False).to_dict().items()},
        "stop_reason_distribution": {str(k): int(v) for k, v in oof["stop_reason"].value_counts(dropna=False).to_dict().items()},
        **{k: v for k, v in total.items() if k not in {"confusion", "labels"}},
        "confusion": total["confusion"],
        "labels": labels,
    }
    write_json(base_analysis / "summary.json", summary)
    controller_manifest = {
        "schema_version": "controller_audit_v1",
        "controller": args.controller,
        "config_sha256": sha256_file(args.config),
        "protocol_sha256": sha256_file(args.protocol),
        "perception_manifest_sha256": sha256_file(perception_run / "shared_perception_manifest.json"),
        "tau_source": tau_source,
        "label_override_permitted": False,
        "official_test_labels_used": False,
    }
    write_json(base_run / "controller_manifest.json", controller_manifest)
    print("CONTROLLER_AUDIT_CV_DONE")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
