# Dataset placement

This repository does not redistribute the UCI Human Activity Recognition Using Smartphones dataset.

1. Download the dataset from the UCI Machine Learning Repository.
2. Extract it so that the following file exists:

```text
data/UCI HAR Dataset/train/Inertial Signals/body_acc_x_train.txt
```

Only the official `train/` partition is used by this implementation. The code
does not load the official UCI `test/` partition or its labels.
